"""
EnergyPlus Gym Environment using the EnergyPlus Python API (v25.2.0+).

Replaces the old pipe-based IPC approach with the built-in pyenergyplus
callback mechanism for direct actuator control and sensor reading.

This module provides a generic base class that can be configured for
any HVAC system by specifying observation variables and actuator definitions
through the ``ep_model`` object.
"""

import os
import shutil
import threading
import queue
from argparse import ArgumentParser
from glob import glob

import numpy as np
import torch
import torch.nn.functional as F
from gym.utils import seeding
from torchlib.common import FloatTensor
from torchlib.deep_rl.envs.model_based import ModelBasedEnv

from gym_energyplus.envs.energyplus_build_model import build_ep_model
from ..path import get_model_filepath, ENERGYPLUS_DIR

try:
    from pyenergyplus.api import EnergyPlusAPI
except ImportError:
    import sys
    if ENERGYPLUS_DIR not in sys.path:
        sys.path.insert(0, ENERGYPLUS_DIR)
    from pyenergyplus.api import EnergyPlusAPI

_STOP_SENTINEL = object()


class EnergyPlusEnv(ModelBasedEnv):
    """OpenAI Gym environment wrapping EnergyPlus via the Python API.

    The simulation runs in a background thread. At each zone timestep a
    callback fires that reads the current state, passes it to the gym
    ``step()`` caller via a queue, and waits for the next action.

    The observation variables and actuator definitions are provided by
    the ``ep_model`` object, making this class generic for any HVAC system.
    """

    metadata = {'render.modes': ['human']}

    def __init__(self,
                 energyplus_file=None,
                 model_file=None,
                 weather_file=None,
                 log_dir=None,
                 config=None,
                 verbose=False):

        self.api = EnergyPlusAPI()
        self.ep_state = None
        self.sim_thread = None
        self.energyplus_running = False

        if model_file is None:
            model_file = get_model_filepath('temp_fan')

        if weather_file is None:
            weather_file = os.getenv('ENERGYPLUS_WEATHER')
        if weather_file is None:
            raise ValueError(
                'EnergyPlus weather file not specified. '
                'Set ENERGYPLUS_WEATHER env var or pass weather_file.'
            )
        if log_dir is None:
            log_dir = os.getenv('ENERGYPLUS_LOG', 'log')

        self.model_file = model_file
        self.weather_files = weather_file.split(',')
        self.log_dir = log_dir

        self.ep_model = build_ep_model(
            model_file=self.model_file, log_dir=self.log_dir, config=config
        )

        self.action_space = self.ep_model.action_space
        self.observation_space = self.ep_model.observation_space
        self.temperature_center = self.ep_model.temperature_center
        self.temperature_tolerance = self.ep_model.temperature_tolerance

        self.obs_variables = self.ep_model.get_obs_variables()
        self.actuator_groups = self.ep_model.get_actuator_config()

        self.episode_idx = -1
        self.verbose = verbose
        self.timestep1 = 0

        self._obs_queue = None
        self._act_queue = None
        self._handles_ready = False
        self._var_handles = {}
        self._actuator_handles = {}

        self.seed()

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    def __del__(self):
        try:
            self.stop_instance()
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Handle setup
    # -----------------------------------------------------------------
    def _setup_handles(self, state):
        """Acquire variable and actuator handles from the running simulation."""
        for var_name, key in self.obs_variables:
            handle = self.api.exchange.get_variable_handle(state, var_name, key)
            if handle == -1:
                print('WARNING: Variable handle not found: {} / {}'.format(var_name, key))
            self._var_handles[(var_name, key)] = handle

        for group_name, actuators in self.actuator_groups.items():
            self._actuator_handles[group_name] = []
            for comp, ctrl, key in actuators:
                h = self.api.exchange.get_actuator_handle(state, comp, ctrl, key)
                if h == -1:
                    print('WARNING: Actuator not found: {} / {} / {}'.format(comp, ctrl, key))
                self._actuator_handles[group_name].append(h)

        self._handles_ready = True

    # -----------------------------------------------------------------
    # Callback invoked by EnergyPlus at each zone timestep
    # -----------------------------------------------------------------
    def _timestep_callback(self, state):
        """Called by EnergyPlus at each zone timestep.

        Flow: read observation -> put in queue -> wait for action -> set actuators.
        """
        if not self.api.exchange.api_data_fully_ready(state):
            return
        if self.api.exchange.warmup_flag(state):
            return

        if not self._handles_ready:
            self._setup_handles(state)

        raw_values = []
        for var_key in self.obs_variables:
            handle = self._var_handles[var_key]
            if handle != -1:
                raw_values.append(
                    self.api.exchange.get_variable_value(state, handle))
            else:
                raw_values.append(0.0)

        raw_state = np.array(raw_values, dtype=np.float32)

        self._obs_queue.put(raw_state)

        try:
            action = self._act_queue.get(timeout=600)
        except queue.Empty:
            return

        if action is _STOP_SENTINEL:
            return

        if action is not None:
            self.ep_model.apply_action(state, action, self._actuator_handles, self.api)

    # -----------------------------------------------------------------
    # Simulation thread
    # -----------------------------------------------------------------
    def _run_simulation(self, state, cmd_args):
        """Run EnergyPlus in a background thread."""
        self.energyplus_running = True
        ret = self.api.runtime.run_energyplus(state, cmd_args)
        self.energyplus_running = False
        self._obs_queue.put(None)
        if ret != 0:
            print('EnergyPlus finished with return code {}'.format(ret))

    # -----------------------------------------------------------------
    # Instance lifecycle
    # -----------------------------------------------------------------
    def start_instance(self):
        print('Starting EnergyPlus environment (Python API, episode {})'.format(self.episode_idx))

        output_dir = os.path.join(
            self.log_dir, 'output', 'episode-{:08d}'.format(self.episode_idx))
        os.makedirs(output_dir, exist_ok=True)

        weather_files_override = glob(self.log_dir + '/*.epw')
        if len(weather_files_override) > 0:
            weather_files_override.sort()
            weather_files = weather_files_override
        else:
            weather_files = self.weather_files

        weather_idx = self.episode_idx % len(weather_files)
        weather_file = weather_files[weather_idx]
        print('start_instance(): weather_files[{}]={}'.format(weather_idx, weather_file))

        shutil.copy(self.model_file, output_dir)
        shutil.copy(weather_file, output_dir)
        copy_model_file = os.path.join(output_dir, os.path.basename(self.model_file))
        copy_weather_file = os.path.join(output_dir, os.path.basename(weather_file))

        self.ep_state = self.api.state_manager.new_state()
        self._handles_ready = False
        self._var_handles = {}
        self._actuator_handles = {}
        self._obs_queue = queue.Queue(maxsize=1)
        self._act_queue = queue.Queue(maxsize=1)

        for var_name, key in self.obs_variables:
            self.api.exchange.request_variable(self.ep_state, var_name, key)

        self.api.runtime.callback_begin_zone_timestep_after_init_heat_balance(
            self.ep_state, self._timestep_callback)

        cmd_args = [
            '-w', copy_weather_file,
            '-d', output_dir,
            '-r', '-x',
            copy_model_file
        ]

        self.sim_thread = threading.Thread(
            target=self._run_simulation,
            args=(self.ep_state, cmd_args),
            daemon=True
        )
        self.sim_thread.start()

    def stop_instance(self):
        if self.energyplus_running and self.ep_state is not None:
            self.api.runtime.stop_simulation(self.ep_state)

        if self._act_queue is not None:
            try:
                self._act_queue.put_nowait(_STOP_SENTINEL)
            except queue.Full:
                pass

        if self.sim_thread is not None and self.sim_thread.is_alive():
            self.sim_thread.join(timeout=30)
            self.sim_thread = None

        if self.ep_state is not None:
            try:
                self.api.state_manager.delete_state(self.ep_state)
            except Exception:
                pass
            self.ep_state = None

        if self.episode_idx >= 0:
            episode_dir = os.path.join(
                self.log_dir, 'output', 'episode-{:08d}'.format(self.episode_idx))
            file_csv = os.path.join(episode_dir, 'eplusout.csv')
            files_to_clean = [
                'eplusmtr.csv', 'eplusout.audit', 'eplusout.bnd',
                'eplusout.dxf', 'eplusout.eio', 'eplusout.edd',
                'eplusout.end', 'eplusout.eso', 'eplusout.mdd',
                'eplusout.mtd', 'eplusout.mtr', 'eplusout.rdd',
                'eplusout.rvaudit', 'eplusout.shd', 'eplusssz.csv',
                'epluszsz.csv', 'sqlite.err'
            ]
            if os.path.isfile(file_csv):
                os.remove(file_csv)
                if not os.path.exists("/tmp/verbose"):
                    for f in files_to_clean:
                        fp = os.path.join(episode_dir, f)
                        if os.path.isfile(fp):
                            os.remove(fp)

    # -----------------------------------------------------------------
    # Gym interface
    # -----------------------------------------------------------------
    def reset(self):
        self.stop_instance()
        self.episode_idx += 1
        self.start_instance()
        self.timestep1 = 0
        self.ep_model.reset()
        return self.step(None)[0]

    def step(self, action):
        self.timestep1 += 1

        if action is not None:
            self.ep_model.set_action(action)
            self._act_queue.put(self.ep_model.action)
        else:
            pass

        try:
            raw_state = self._obs_queue.get(timeout=600)
        except queue.Empty:
            print('EnergyPlusEnv.step(): Timeout waiting for observation.')
            observation = (self.observation_space.low + self.observation_space.high) * 0.5
            return observation, 0.0, True, {}

        if raw_state is None:
            self.ep_model.set_raw_state(None)
            observation = self.ep_model.get_state()
            reward = self.ep_model.compute_reward()
            print('EnergyPlusEnv: (done)')
            return observation, reward, True, {}

        self.ep_model.set_raw_state(raw_state)
        observation = self.ep_model.get_state()
        reward = self.ep_model.compute_reward()

        if self.verbose:
            print('Step {}: reward={:.4f}'.format(self.timestep1, reward))

        return observation, reward, False, {}

    def render(self, mode='human'):
        if mode == 'human':
            return False

    def close(self):
        self.stop_instance()

    def plot(self, log_dir='', csv_file=''):
        self.ep_model.plot(log_dir=log_dir, csv_file=csv_file)

    def dump_timesteps(self, log_dir='', csv_file='', reward_file=''):
        self.ep_model.dump_timesteps(log_dir=log_dir, csv_file=csv_file)

    def dump_episodes(self, log_dir='', csv_file='', reward_file=''):
        self.ep_model.dump_episodes(log_dir=log_dir, csv_file=csv_file)

    def cost_fn(self, states, actions, next_states):
        return self.ep_model.cost_fn_tensor(
            states, actions, next_states,
            self.temperature_center, self.temperature_tolerance)
