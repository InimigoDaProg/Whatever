"""
Hierarchical Grid-Interactive HVAC Agent.

Two-level control architecture:

  HIGH-LEVEL POLICY (decides every N steps, e.g. every 1-4 hours):
    Observes: grid forecast, weather forecast, storage state, time-of-day
    Decides:  thermal strategy mode (CHARGE / DISCHARGE / NORMAL)
    Method:   Rule-based + learned value estimation

  LOW-LEVEL MPC (decides every timestep, e.g. every 15 minutes):
    Observes: zone temperatures, tank temperatures, outdoor conditions
    Receives: mode command from high-level
    Decides:  exact setpoint values [htg_sp, clg_sp, hw_T, dhw_sp]
    Method:   CEM planner with ensemble dynamics model

This separation allows:
  - Long-horizon strategic thinking (when to charge/discharge)
  - Short-horizon precise control (exact setpoints)
  - Safety constraints always enforced at low level
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import deque


# ====================================================================
# HIGH-LEVEL: Strategy Policy Network
# ====================================================================

class StrategyNetwork(nn.Module):
    """Neural network that estimates the value of each mode given context.

    Input: [grid_excess, elec_price, buffer_temp, dhw_temp,
            avg_zone_temp, outdoor_temp, hour_sin, hour_cos,
            buffer_charge_frac, dhw_charge_frac]

    Output: Q-values for 3 modes [CHARGE, DISCHARGE, NORMAL]
    """

    def __init__(self, input_dim=10, hidden_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 3),
        )

    def forward(self, x):
        return self.net(x)


class HighLevelPolicy:
    """High-level strategy selector using DQN-style learning.

    Modes:
      0 = CHARGE:    Aggressively store thermal energy
      1 = DISCHARGE: Minimize grid draw, use stored energy
      2 = NORMAL:    Standard comfort-optimal operation
    """

    MODE_CHARGE = 0
    MODE_DISCHARGE = 1
    MODE_NORMAL = 2
    MODE_NAMES = ['CHARGE', 'DISCHARGE', 'NORMAL']

    def __init__(self, learning_rate=1e-3, gamma=0.99, epsilon_start=1.0,
                 epsilon_end=0.05, epsilon_decay=5000, buffer_size=10000,
                 device='cpu'):
        self.device = torch.device(device)
        self.gamma = gamma
        self.epsilon = epsilon_start
        self.epsilon_end = epsilon_end
        self.epsilon_decay = epsilon_decay
        self.step_count = 0

        self.q_net = StrategyNetwork().to(self.device)
        self.target_net = StrategyNetwork().to(self.device)
        self.target_net.load_state_dict(self.q_net.state_dict())
        self.optimizer = torch.optim.Adam(
            self.q_net.parameters(), lr=learning_rate)

        self.replay_buffer = deque(maxlen=buffer_size)
        self.batch_size = 64
        self.target_update_freq = 100

    def extract_features(self, obs, ep_model=None):
        """Extract high-level features from full observation.

        obs: [outdoor_T, living_T, kitchen_T, bedroom_T, bathroom_T,
              buffer_T, dhw_T, total_W, hvac_W, grid_excess,
              elec_price, outdoor_RH, avg_zone_T]
        """
        import math

        grid_excess = obs[9]
        elec_price = obs[10]
        buffer_temp = obs[5]
        dhw_temp = obs[6]
        avg_zone = obs[12]
        outdoor_temp = obs[0]

        hour = (self.step_count % 96) / 96.0 * 24.0
        hour_sin = math.sin(2 * math.pi * hour / 24.0)
        hour_cos = math.cos(2 * math.pi * hour / 24.0)

        buffer_frac = np.clip((buffer_temp - 30.0) / (80.0 - 30.0), 0, 1)
        dhw_frac = np.clip((dhw_temp - 45.0) / (65.0 - 45.0), 0, 1)

        features = np.array([
            grid_excess / 10000.0,
            elec_price,
            buffer_temp / 80.0,
            dhw_temp / 65.0,
            avg_zone / 30.0,
            outdoor_temp / 40.0,
            hour_sin,
            hour_cos,
            buffer_frac,
            dhw_frac,
        ], dtype=np.float32)

        return features

    def select_mode(self, obs, ep_model=None):
        """Select operating mode using epsilon-greedy DQN policy."""
        features = self.extract_features(obs, ep_model)
        self.step_count += 1

        self.epsilon = max(
            self.epsilon_end,
            self.epsilon - (1.0 - self.epsilon_end) / self.epsilon_decay
        )

        if np.random.random() < self.epsilon:
            mode = np.random.randint(3)
        else:
            with torch.no_grad():
                feat_t = torch.tensor(
                    features, dtype=torch.float32, device=self.device
                ).unsqueeze(0)
                q_values = self.q_net(feat_t)
                mode = q_values.argmax(dim=1).item()

        return mode, self.MODE_NAMES[mode]

    def store_transition(self, features, mode, reward, next_features, done):
        self.replay_buffer.append(
            (features, mode, reward, next_features, done))

    def update(self):
        """Train Q-network from replay buffer."""
        if len(self.replay_buffer) < self.batch_size:
            return 0.0

        indices = np.random.choice(
            len(self.replay_buffer), self.batch_size, replace=False)
        batch = [self.replay_buffer[i] for i in indices]

        feats = torch.tensor(
            np.array([b[0] for b in batch]),
            dtype=torch.float32, device=self.device)
        modes = torch.tensor(
            [b[1] for b in batch],
            dtype=torch.long, device=self.device)
        rewards = torch.tensor(
            [b[2] for b in batch],
            dtype=torch.float32, device=self.device)
        next_feats = torch.tensor(
            np.array([b[3] for b in batch]),
            dtype=torch.float32, device=self.device)
        dones = torch.tensor(
            [b[4] for b in batch],
            dtype=torch.float32, device=self.device)

        q_values = self.q_net(feats).gather(1, modes.unsqueeze(1)).squeeze(1)

        with torch.no_grad():
            next_q = self.target_net(next_feats).max(dim=1)[0]
            target = rewards + self.gamma * next_q * (1.0 - dones)

        loss = F.mse_loss(q_values, target)
        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.q_net.parameters(), 1.0)
        self.optimizer.step()

        if self.step_count % self.target_update_freq == 0:
            self.target_net.load_state_dict(self.q_net.state_dict())

        return loss.item()


# ====================================================================
# INTEGRATED HIERARCHICAL AGENT
# ====================================================================

class HierarchicalGridAgent:
    """Two-level hierarchical agent for grid-interactive HVAC control.

    Usage:
        agent = HierarchicalGridAgent(dynamics, cost_fn, action_space, ...)
        agent.fit_dynamics(states, actions, next_states)  # train world model

        obs = env.reset()
        for step in range(episode_length):
            action = agent.predict(obs)
            next_obs, reward, done, info = env.step(action)
            agent.observe(obs, action, reward, next_obs, done)  # learn
            obs = next_obs
    """

    def __init__(self, dynamics_model, cost_fn, action_low, action_high,
                 high_level_interval=16, mpc_horizon=5,
                 cem_candidates=200, cem_elites=20, cem_iterations=5,
                 uncertainty_penalty=1.0, device='cpu'):
        """
        Args:
            dynamics_model: EnsembleDynamicsModel
            cost_fn: callable for CEM planner
            action_low/high: action space bounds
            high_level_interval: steps between high-level decisions (16 = 4 hours)
            mpc_horizon: CEM planning horizon
        """
        from agent.cem_planner import CEMPlanner

        self.dynamics = dynamics_model
        self.action_dim = len(action_low)
        self.device = device

        self.high_level = HighLevelPolicy(device=device)
        self.low_level = CEMPlanner(
            dynamics_model=dynamics_model,
            cost_fn=cost_fn,
            action_dim=self.action_dim,
            action_low=action_low,
            action_high=action_high,
            horizon=mpc_horizon,
            num_candidates=cem_candidates,
            num_elites=cem_elites,
            cem_iterations=cem_iterations,
            uncertainty_penalty=uncertainty_penalty,
            device=device,
        )

        self.high_level_interval = high_level_interval
        self.current_mode = HighLevelPolicy.MODE_NORMAL
        self.current_mode_name = 'NORMAL'
        self.step_in_episode = 0
        self.mode_reward_accum = 0.0
        self.mode_start_features = None

        self._data_states = []
        self._data_actions = []
        self._data_next_states = []

    def reset(self):
        """Reset at episode boundary."""
        self.step_in_episode = 0
        self.current_mode = HighLevelPolicy.MODE_NORMAL
        self.current_mode_name = 'NORMAL'
        self.mode_reward_accum = 0.0
        self.mode_start_features = None
        self.low_level.reset()

    def predict(self, obs):
        """Select action given current observation.

        1) Every high_level_interval steps: high-level selects mode
        2) Every step: low-level CEM plans exact setpoints
        """
        if self.step_in_episode % self.high_level_interval == 0:
            if self.mode_start_features is not None:
                next_features = self.high_level.extract_features(obs)
                self.high_level.store_transition(
                    self.mode_start_features,
                    self.current_mode,
                    self.mode_reward_accum,
                    next_features,
                    False
                )
                self.high_level.update()

            self.current_mode, self.current_mode_name = \
                self.high_level.select_mode(obs)
            self.mode_start_features = self.high_level.extract_features(obs)
            self.mode_reward_accum = 0.0

        mode_context = {
            'mode': self.current_mode_name.lower(),
        }

        if self.dynamics._trained:
            action, plan_info = self.low_level.plan(obs, mode_context)
        else:
            action = np.random.uniform(
                self.low_level.action_low.cpu().numpy(),
                self.low_level.action_high.cpu().numpy()
            )

        self.step_in_episode += 1
        return action

    def observe(self, obs, action, reward, next_obs, done):
        """Store experience for learning."""
        self.mode_reward_accum += reward

        self._data_states.append(obs.copy())
        self._data_actions.append(action.copy())
        self._data_next_states.append(next_obs.copy())

        if done:
            if self.mode_start_features is not None:
                next_features = self.high_level.extract_features(next_obs)
                self.high_level.store_transition(
                    self.mode_start_features,
                    self.current_mode,
                    self.mode_reward_accum,
                    next_features,
                    True
                )
                self.high_level.update()

    def fit_dynamics(self, epochs=50, verbose=False):
        """Train the ensemble dynamics model on collected data."""
        if len(self._data_states) < 100:
            if verbose:
                print('  Not enough data for dynamics training '
                      '({} samples)'.format(len(self._data_states)))
            return

        states = np.array(self._data_states)
        actions = np.array(self._data_actions)
        next_states = np.array(self._data_next_states)

        if verbose:
            print('  Training dynamics on {} samples...'.format(len(states)))

        self.dynamics.fit(
            states, actions, next_states,
            epochs=epochs, verbose=verbose)

    def get_diagnostics(self):
        return {
            'mode': self.current_mode_name,
            'epsilon': self.high_level.epsilon,
            'data_size': len(self._data_states),
            'dynamics_trained': self.dynamics._trained,
        }
