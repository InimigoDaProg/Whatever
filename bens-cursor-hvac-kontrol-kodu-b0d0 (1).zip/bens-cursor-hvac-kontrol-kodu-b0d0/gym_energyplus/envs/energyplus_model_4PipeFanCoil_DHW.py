"""
Grid-Interactive 4-Pipe Fan Coil + DHW Thermal Storage Controller.
Configured for: Porto (Portugal) residential building - renato17 model.

Building: 5 zones (GF_Living_Room, GF_Kitchen, UF_Bedroom, UF_Bathroom, UF_Storage_Room)
HVAC: 5x FourPipeFanCoil + BufferTank 500L (15kW) + DHW_Tank 200L (6kW) + Chiller COP 5.5
Thermostat: Heating 20C / Cooling 26C (dual setpoint)

The RL agent does NOT directly know the building's U-values, material properties,
or thermal mass. Instead, the LSTM dynamics model learns the INPUT-OUTPUT relationship
from simulation data. The effect of U=2.4 W/m2K windows, 6cm EPS insulation, and
20cm concrete slab thermal mass is implicitly captured through the observed temperature
response to setpoint changes.
"""

import os
import numpy as np
from gym import spaces

from gym_energyplus.envs.energyplus_model import EnergyPlusModel


class EnergyPlusModel4PipeFanCoilDHW(EnergyPlusModel):
    """Grid-Interactive Fan Coil + DHW controller for Porto residential building.

    Raw state from EnergyPlus (15 values):
      [0]  Site Outdoor Air Drybulb Temperature (C)
      [1]  GF_Living_Room Zone Mean Air Temperature (C)
      [2]  GF_Kitchen Zone Mean Air Temperature (C)
      [3]  UF_Bedroom Zone Mean Air Temperature (C)
      [4]  UF_Bathroom Zone Mean Air Temperature (C)
      [5]  UF_Storage_Room Zone Mean Air Temperature (C)
      [6]  BufferTank Water Heater Tank Temperature (C)
      [7]  DHW_Tank Water Heater Tank Temperature (C)
      [8]  Facility Total Electric Demand Power (W)
      [9]  Facility Total HVAC Electric Demand Power (W)
      [10] Water Heater Heating Energy - BufferTank (J)
      [11] Water Heater Heating Energy - DHW_Tank (J)
      [12] Grid excess power signal from schedule (W)
      [13] Electricity price signal from schedule (unit/kWh)
      [14] Site Outdoor Air Relative Humidity (%)

    Formatted observation for RL agent (13 values):
      [0]  Outdoor temperature (C)
      [1]  Living room temperature (C)      -- main comfort zone
      [2]  Kitchen temperature (C)
      [3]  Bedroom temperature (C)          -- main comfort zone
      [4]  Bathroom temperature (C)
      [5]  Buffer tank temperature (C)      -- HW thermal storage state
      [6]  DHW tank temperature (C)         -- DHW storage state
      [7]  Total electric power (W)
      [8]  HVAC electric power (W)
      [9]  Grid excess signal (W)           -- grid context
      [10] Electricity price (unit/kWh)     -- cost context
      [11] Outdoor relative humidity (%)
      [12] Avg zone temperature (C)         -- overall comfort metric

    Action vector (4 values):
      [0] Heating setpoint (C)              15-24  -> HTG_Setpoint_Sch override
      [1] Cooling setpoint (C)              22-28  -> CLG_Setpoint_Sch override
      [2] HW supply temperature (C)         30-80  -> HW_SupplyTemp_Sch override
      [3] DHW tank setpoint (C)             45-65  -> DHW_TSET_SCH override
    """

    # ----------------------------------------------------------------
    # EnergyPlus output variables - MATCHED to renato17 IDF
    # ----------------------------------------------------------------
    OBS_VARIABLES = [
        ("Site Outdoor Air Drybulb Temperature", "Environment"),
        ("Zone Mean Air Temperature", "GF_Living_Room"),
        ("Zone Mean Air Temperature", "GF_Kitchen"),
        ("Zone Mean Air Temperature", "UF_Bedroom"),
        ("Zone Mean Air Temperature", "UF_Bathroom"),
        ("Zone Mean Air Temperature", "UF_Storage_Room"),
        ("Water Heater Tank Temperature", "BufferTank"),
        ("Water Heater Tank Temperature", "DHW_Tank"),
        ("Facility Total Electric Demand Power", "Whole Building"),
        ("Facility Total HVAC Electric Demand Power", "Whole Building"),
        ("Water Heater Heating Energy", "BufferTank"),
        ("Water Heater Heating Energy", "DHW_Tank"),
        ("Schedule Value", "GRID_EXCESS_POWER_SCHEDULE"),
        ("Schedule Value", "ELECTRICITY_PRICE_SCHEDULE"),
        ("Site Outdoor Air Relative Humidity", "Environment"),
    ]

    # ----------------------------------------------------------------
    # Actuators - override schedule values via Python API
    # ----------------------------------------------------------------
    ACTUATOR_CONFIG = {
        'heating_setpoint': [
            ("Schedule:Constant", "Schedule Value", "HTG_Setpoint_Sch"),
        ],
        'cooling_setpoint': [
            ("Schedule:Constant", "Schedule Value", "CLG_Setpoint_Sch"),
        ],
        'hw_supply_temp': [
            ("Schedule:Compact", "Schedule Value", "HW_SupplyTemp_Sch"),
        ],
        'dhw_setpoint': [
            ("Schedule:Compact", "Schedule Value", "DHW_TSET_SCH"),
        ],
    }

    # ----------------------------------------------------------------
    # System parameters from IDF
    # ----------------------------------------------------------------
    BUFFER_TANK_VOLUME_L = 500.0    # 0.5 m3
    BUFFER_TANK_MAX_POWER_W = 15000
    BUFFER_TANK_MAX_TEMP = 90.0

    DHW_TANK_VOLUME_L = 200.0       # 0.2 m3
    DHW_TANK_MAX_POWER_W = 6000
    DHW_TANK_MAX_TEMP = 60.0

    CHILLER_COP = 5.5

    COMFORT_TEMP_HEAT = 20.0        # default heating setpoint
    COMFORT_TEMP_COOL = 26.0        # default cooling setpoint
    COMFORT_TEMP_MIN = 18.0         # absolute minimum
    COMFORT_TEMP_MAX = 28.0         # absolute maximum

    DHW_MIN_TEMP = 45.0             # legionella safety
    DHW_NOMINAL_TEMP = 55.0

    def __init__(self, model_file, log_dir, config=None, verbose=False):
        self.reward_low_limit = -10000.
        if config is None:
            config = {}

        self.temperature_center = config.get('temp_center', 22.0)
        self.temperature_tolerance = config.get('temp_tolerance', 2.0)
        self.dhw_target = config.get('dhw_target', self.DHW_NOMINAL_TEMP)

        self.w_comfort = config.get('w_comfort', 2.0)
        self.w_grid_flex = config.get('w_grid_flex', 1.0)
        self.w_energy_cost = config.get('w_energy_cost', 0.5)
        self.w_smoothness = config.get('w_smoothness', 0.1)

        self.hvac_max_power_w = config.get(
            'hvac_max_power',
            self.BUFFER_TANK_MAX_POWER_W + self.DHW_TANK_MAX_POWER_W)

        super(EnergyPlusModel4PipeFanCoilDHW, self).__init__(
            model_file, log_dir, verbose)

    # ----------------------------------------------------------------
    # Spaces
    # ----------------------------------------------------------------
    def setup_spaces(self):
        # Actions: [htg_sp, clg_sp, hw_supply_temp, dhw_sp]
        self.action_space = spaces.Box(
            low=np.array([15.0, 22.0, 30.0, 45.0], dtype=np.float32),
            high=np.array([24.0, 28.0, 80.0, 65.0], dtype=np.float32),
        )

        # Observations: 13 values
        self.observation_space = spaces.Box(
            low=np.array([-10, 5, 5, 5, 5, 10, 10, 0, 0, -1e6, 0, 0, 5],
                         dtype=np.float32),
            high=np.array([45, 40, 40, 40, 40, 95, 70, 5e5, 5e5, 1e6, 10, 100, 40],
                          dtype=np.float32),
        )

    # ----------------------------------------------------------------
    # Python API interface
    # ----------------------------------------------------------------
    def get_obs_variables(self):
        return self.OBS_VARIABLES

    def get_actuator_config(self):
        return self.ACTUATOR_CONFIG

    def apply_action(self, ep_state, action, actuator_handles, api):
        mapping = {
            'heating_setpoint': float(action[0]),
            'cooling_setpoint': float(action[1]),
            'hw_supply_temp': float(action[2]),
            'dhw_setpoint': float(action[3]),
        }
        for group, value in mapping.items():
            for h in actuator_handles.get(group, []):
                if h != -1:
                    api.exchange.set_actuator_value(ep_state, h, value)

    # ----------------------------------------------------------------
    # State processing
    # ----------------------------------------------------------------
    def set_raw_state(self, raw_state):
        if raw_state is not None:
            self.raw_state = raw_state
        else:
            self.raw_state = np.zeros(len(self.OBS_VARIABLES), dtype=np.float32)
            self.raw_state[1:6] = self.temperature_center
            self.raw_state[6] = 50.0
            self.raw_state[7] = self.dhw_target

    def format_state(self, raw_state):
        zone_temps = raw_state[1:6]
        avg_zone_temp = np.mean(zone_temps)

        return np.array([
            raw_state[0],              # [0]  outdoor temp
            raw_state[1],              # [1]  living room temp
            raw_state[2],              # [2]  kitchen temp
            raw_state[3],              # [3]  bedroom temp
            raw_state[4],              # [4]  bathroom temp
            raw_state[6],              # [5]  buffer tank temp
            raw_state[7],              # [6]  DHW tank temp
            raw_state[8],              # [7]  total electric (W)
            raw_state[9],              # [8]  HVAC electric (W)
            raw_state[12],             # [9]  grid excess signal
            raw_state[13],             # [10] electricity price
            raw_state[14],             # [11] outdoor RH
            avg_zone_temp,             # [12] avg zone temperature
        ], dtype=np.float32)

    # ----------------------------------------------------------------
    # Thermal storage metrics
    # ----------------------------------------------------------------
    def buffer_stored_kwh(self):
        Cp = 4.186
        T = max(self.raw_state[6], 20.0)
        return self.BUFFER_TANK_VOLUME_L * Cp * (T - 20.0) / 3600.0

    def dhw_stored_kwh(self):
        Cp = 4.186
        T = max(self.raw_state[7], self.DHW_MIN_TEMP)
        return self.DHW_TANK_VOLUME_L * Cp * (T - self.DHW_MIN_TEMP) / 3600.0

    def total_storage_capacity_kwh(self):
        Cp = 4.186
        buf_cap = self.BUFFER_TANK_VOLUME_L * Cp * (self.BUFFER_TANK_MAX_TEMP - 20.0) / 3600.0
        dhw_cap = self.DHW_TANK_VOLUME_L * Cp * (self.DHW_TANK_MAX_TEMP - self.DHW_MIN_TEMP) / 3600.0
        return buf_cap + dhw_cap

    # ================================================================
    # REWARD FUNCTION
    # ================================================================
    def compute_reward(self):
        return self._compute_reward()[0]

    def _compute_reward(self, raw_state=None):
        st = raw_state if raw_state is not None else self.raw_state

        zone_temps = st[1:6]
        avg_temp = np.mean(zone_temps)
        buffer_temp = st[6]
        dhw_temp = st[7]
        total_elec = st[8]
        hvac_elec = st[9]
        buffer_energy_j = st[10]
        dhw_energy_j = st[11]
        grid_excess = st[12]
        elec_price = st[13]

        timestep_s = 900.0
        buffer_power = buffer_energy_j / timestep_s
        dhw_power = dhw_energy_j / timestep_s

        # ---- 1) ZONE COMFORT ----
        tc = self.temperature_center
        tol = self.temperature_tolerance
        r_comfort = 0.0
        for zt in zone_temps:
            r_comfort += np.exp(-(zt - tc) ** 2 * 0.5)
            if zt < (tc - tol):
                r_comfort -= 0.3 * (tc - tol - zt)
            elif zt > (tc + tol):
                r_comfort -= 0.3 * (zt - tc - tol)
            if zt < self.COMFORT_TEMP_MIN:
                r_comfort -= 1.0 * (self.COMFORT_TEMP_MIN - zt)
            elif zt > self.COMFORT_TEMP_MAX:
                r_comfort -= 1.0 * (zt - self.COMFORT_TEMP_MAX)
        r_comfort /= len(zone_temps)

        # ---- 2) DHW SAFETY ----
        r_dhw = 0.0
        if dhw_temp < self.DHW_MIN_TEMP:
            r_dhw = -0.5 * (self.DHW_MIN_TEMP - dhw_temp)

        r_comfort_total = (r_comfort + r_dhw) * self.w_comfort

        # ---- 3) GRID FLEXIBILITY ----
        building_load = buffer_power + dhw_power + max(hvac_elec, 0)
        if grid_excess > 0:
            utilization = min(building_load, grid_excess) / max(grid_excess, 1.0)
            r_grid = utilization
        elif grid_excess < 0:
            shed = 1.0 - (building_load / max(self.hvac_max_power_w, 1.0))
            r_grid = max(0, shed)
        else:
            r_grid = 0.0
        r_grid *= self.w_grid_flex

        # ---- 4) ENERGY COST ----
        r_cost = -(total_elec * max(elec_price, 0.0)) / 100000.0 * self.w_energy_cost

        # ---- 5) SMOOTHNESS ----
        r_smooth = 0.0
        for cur, prev in zip(self.action, self.action_prev):
            r_smooth -= abs(cur - prev) * 0.01
        r_smooth *= self.w_smoothness

        rew = r_comfort_total + r_grid + r_cost + r_smooth

        return rew, {
            'comfort': r_comfort_total, 'grid': r_grid,
            'cost': r_cost, 'smooth': r_smooth,
            'avg_temp': avg_temp, 'buffer_T': buffer_temp,
            'dhw_T': dhw_temp, 'grid_excess': grid_excess,
        }

    # ----------------------------------------------------------------
    # Cost function for MBRL planner (tensor batch)
    # ----------------------------------------------------------------
    def cost_fn_tensor(self, states, actions, next_states, temp_center, temp_tolerance):
        import torch
        import torch.nn.functional as F
        from torchlib.common import FloatTensor

        avg_zone = next_states[:, 12]
        buffer_T = next_states[:, 5]
        dhw_T = next_states[:, 6]
        total_elec = next_states[:, 7]
        grid_excess = next_states[:, 9]
        elec_price = next_states[:, 10]

        temp_viol = (
            F.relu(avg_zone - (temp_center + temp_tolerance))
            + F.relu((temp_center - temp_tolerance) - avg_zone)
        ).type(FloatTensor)
        gauss = torch.exp(-(avg_zone - temp_center) ** 2 * 0.5)

        dhw_viol = F.relu(torch.tensor(self.DHW_MIN_TEMP) - dhw_T).type(FloatTensor)

        comfort_cost = temp_viol * 0.3 - gauss * 1.0 + dhw_viol * 0.5

        energy_cost = total_elec * elec_price.clamp(min=0.0) / 100000.0

        grid_cost = torch.where(
            grid_excess > 0,
            -total_elec / grid_excess.clamp(min=1.0),
            total_elec / torch.tensor(self.hvac_max_power_w, dtype=torch.float32),
        )

        cost = (comfort_cost * self.w_comfort
                + grid_cost * self.w_grid_flex
                + energy_cost * self.w_energy_cost)
        return cost

    # ----------------------------------------------------------------
    # Stubs for plotting
    # ----------------------------------------------------------------
    def read_episode(self, ep):
        pass

    def plot_episode(self, ep):
        pass

    def dump_timesteps(self, log_dir='', csv_file='', **kwargs):
        pass

    def dump_episodes(self, log_dir='', csv_file='', **kwargs):
        pass
