"""
Two-Stage Training for Grid-Interactive 4-Pipe Fan Coil + DHW Thermal Storage.

Stage 1: CAPACITY ESTIMATION
  Run baseline (PID) controller to measure:
  - Peak HVAC electric power (kW)
  - Peak DHW heater power (kW)
  - DHW thermal storage capacity (kWh)
  - Building thermal time constant (hours)

Stage 2: GRID-INTERACTIVE RL TRAINING
  Train MBRL agent that observes grid excess signal and optimizes
  thermal charging/discharging while maintaining comfort.

Usage:
  # Stage 1 - Measure system capacity
  python train_4pipe_fancoil.py stage1 \\
      --model_file your_model.idf --weather_file weather.epw

  # Stage 2 - Train grid-interactive controller
  python train_4pipe_fancoil.py stage2 \\
      --model_file your_model.idf --weather_file weather.epw \\
      --hvac_max_power 5000 --dhw_tank_volume 300
"""

import os
import sys
import json
import numpy as np
import pprint
from argparse import ArgumentParser

from gym_energyplus.envs.energyplus_env import EnergyPlusEnv
from gym_energyplus.wrappers import EnergyPlusSplitEpisodeWrapper, Monitor


# ====================================================================
# STAGE 1: Baseline PID + Capacity Estimation
# ====================================================================

class BaselinePIDAgent:
    """Simple PID controller for baseline capacity measurement.

    Maintains zone temperature near target with fixed DHW setpoint.
    Logs power consumption to estimate system capacity.
    """
    def __init__(self, action_space, temp_target=22.0, dhw_target=55.0):
        self.action_space = action_space
        self.temp_target = temp_target
        self.dhw_target = dhw_target
        self.prev_cool_sp = 24.0
        self.prev_heat_sp = 20.0
        self.alpha = 0.3

        self.peak_hvac_power = 0.0
        self.peak_dhw_power = 0.0
        self.peak_total_power = 0.0
        self.total_energy_kwh = 0.0
        self.timestep_count = 0
        self.timestep_seconds = 900.0  # 15 min default

    def predict(self, obs):
        """obs: [outdoor_T, zone_T, zone_RH, dhw_T, hvac_W, dhw_W,
                 grid_excess, elec_price, total_W, fancoil_T, outdoor_HR]
        """
        zone_temp = obs[1]
        hvac_power = obs[4]
        dhw_power = obs[5]
        total_power = obs[8]

        self.peak_hvac_power = max(self.peak_hvac_power, hvac_power)
        self.peak_dhw_power = max(self.peak_dhw_power, dhw_power)
        self.peak_total_power = max(self.peak_total_power, total_power)
        self.total_energy_kwh += total_power * self.timestep_seconds / 3.6e6
        self.timestep_count += 1

        delta = zone_temp - self.temp_target
        cool_sp = np.clip(self.temp_target + 2.0 - delta * 0.5, 20.0, 28.0)
        heat_sp = np.clip(self.temp_target - 2.0 - delta * 0.5, 15.0, 24.0)

        cool_sp = self.alpha * cool_sp + (1 - self.alpha) * self.prev_cool_sp
        heat_sp = self.alpha * heat_sp + (1 - self.alpha) * self.prev_heat_sp
        self.prev_cool_sp = cool_sp
        self.prev_heat_sp = heat_sp

        fan_speed = 0.5
        dhw_sp = self.dhw_target

        action = np.array([cool_sp, heat_sp, fan_speed, dhw_sp, 1.0],
                          dtype=np.float32)
        return np.clip(action, self.action_space.low, self.action_space.high)

    def report(self):
        print('\n' + '=' * 60)
        print('  STAGE 1: System Capacity Report')
        print('=' * 60)
        print('  Peak HVAC electric power:   {:>10,.0f} W  ({:.1f} kW)'.format(
            self.peak_hvac_power, self.peak_hvac_power / 1000))
        print('  Peak DHW heater power:      {:>10,.0f} W  ({:.1f} kW)'.format(
            self.peak_dhw_power, self.peak_dhw_power / 1000))
        print('  Peak total facility power:  {:>10,.0f} W  ({:.1f} kW)'.format(
            self.peak_total_power, self.peak_total_power / 1000))
        print('  Total energy consumed:      {:>10,.1f} kWh'.format(
            self.total_energy_kwh))
        print('  Simulation timesteps:       {:>10,d}'.format(
            self.timestep_count))
        if self.timestep_count > 0:
            avg_power = self.total_energy_kwh / (self.timestep_count *
                                                  self.timestep_seconds / 3600) * 1000
            print('  Average power:              {:>10,.0f} W  ({:.1f} kW)'.format(
                avg_power, avg_power / 1000))
        print('=' * 60)
        return {
            'peak_hvac_power_w': self.peak_hvac_power,
            'peak_dhw_power_w': self.peak_dhw_power,
            'peak_total_power_w': self.peak_total_power,
            'total_energy_kwh': self.total_energy_kwh,
            'timesteps': self.timestep_count,
        }


def run_stage1(model_file, weather_file, temp_center, dhw_target, dhw_tank_volume):
    """Run baseline simulation to estimate system capacity."""
    print('\n*** STAGE 1: Capacity Estimation (PID baseline) ***\n')

    config = {
        'temp_center': temp_center,
        'temp_tolerance': 1.5,
        'dhw_target': dhw_target,
        'dhw_tank_volume': dhw_tank_volume,
        'hvac_max_power': 50000,  # placeholder - will be measured
    }

    log_dir = 'runs/stage1_capacity'
    env = EnergyPlusEnv(
        model_file=model_file,
        weather_file=weather_file,
        config=config,
        verbose=False
    )
    env = Monitor(env, log_dir=log_dir)
    env = EnergyPlusSplitEpisodeWrapper(env, max_steps=96 * 1)

    agent = BaselinePIDAgent(env.action_space, temp_target=temp_center,
                             dhw_target=dhw_target)

    true_done = False
    day = 0
    while not true_done:
        obs = env.reset()
        done = False
        info = {}
        while not done:
            action = agent.predict(obs)
            obs, reward, done, info = env.step(action)
        day += 1
        true_done = info.get('true_done', day >= 365)
        if day % 30 == 0:
            print('  Day {}/365 | Peak HVAC: {:.0f}W | Peak DHW: {:.0f}W'.format(
                day, agent.peak_hvac_power, agent.peak_dhw_power))

    report = agent.report()

    Cp = 4.186  # kJ/(kg*K)
    dhw_capacity_kwh = dhw_tank_volume * Cp * (80.0 - 45.0) / 3600.0
    report['dhw_thermal_capacity_kwh'] = dhw_capacity_kwh
    print('  DHW tank thermal capacity:  {:>10,.1f} kWh  '
          '({}L x {:.0f}K)'.format(dhw_capacity_kwh, dhw_tank_volume, 80.0-45.0))

    report_path = os.path.join(log_dir, 'capacity_report.json')
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)
    print('\n  Report saved to: {}'.format(report_path))

    env.close()
    return report


# ====================================================================
# STAGE 2: Grid-Interactive MBRL Training
# ====================================================================

def run_stage2(model_file, weather_file, temp_center, temp_tolerance,
               dhw_target, dhw_tank_volume, hvac_max_power,
               window_length, num_years, mpc_horizon, gamma,
               num_random_action_selection, training_epochs,
               training_batch_size, num_init_random_rollouts,
               num_days_on_policy, dagger,
               w_comfort, w_grid_flex, w_energy_cost):
    """Train grid-interactive RL controller."""
    print('\n*** STAGE 2: Grid-Interactive MBRL Training ***\n')

    from torchlib.deep_rl import RandomAgent
    from torchlib.utils.random.sampler import UniformSampler
    from agent import (ModelBasedHistoryPlanAgent,
                       ModelBasedHistoryDaggerAgent,
                       EnergyPlusDynamicsModel,
                       BestRandomActionHistoryPlanner)
    from agent.utils import EpisodicHistoryDataset, gather_rollouts

    config = {
        'temp_center': temp_center,
        'temp_tolerance': temp_tolerance,
        'dhw_target': dhw_target,
        'dhw_tank_volume': dhw_tank_volume,
        'hvac_max_power': hvac_max_power,
        'w_comfort': w_comfort,
        'w_grid_flex': w_grid_flex,
        'w_energy_cost': w_energy_cost,
    }

    log_dir = 'runs/stage2_grid_interactive_{}_{}_{}'.format(
        temp_center, mpc_horizon, dagger)

    env = EnergyPlusEnv(
        model_file=model_file,
        weather_file=weather_file,
        config=config,
        verbose=False
    )
    env = Monitor(env, log_dir=log_dir)
    env = EnergyPlusSplitEpisodeWrapper(env, max_steps=96 * 1)

    dataset_maxlen = 96 * 120  # ~120 days of data
    dataset = EpisodicHistoryDataset(maxlen=dataset_maxlen,
                                     window_length=window_length)

    baseline_agent = RandomAgent(env.action_space)

    print('Gathering initial dataset ({} rollouts)...'.format(
        num_init_random_rollouts))
    initial_data = gather_rollouts(env, baseline_agent,
                                   num_init_random_rollouts, np.inf)
    dataset.append(initial_data)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    print('State dim: {}, Action dim: {}'.format(state_dim, action_dim))

    model = EnergyPlusDynamicsModel(
        state_dim=state_dim,
        action_dim=action_dim,
        hidden_size=64,
        learning_rate=1e-3,
        log_dir=log_dir
    )

    action_sampler = UniformSampler(
        low=env.action_space.low, high=env.action_space.high)
    planner = BestRandomActionHistoryPlanner(
        model, action_sampler, env.cost_fn,
        horizon=mpc_horizon,
        num_random_action_selection=num_random_action_selection,
        gamma=gamma
    )

    if dagger:
        agent = ModelBasedHistoryDaggerAgent(
            model=model, planner=planner, policy_data_size=10000,
            window_length=window_length, baseline_agent=baseline_agent,
            state_dim=state_dim, action_dim=action_dim, hidden_size=64
        )
    else:
        agent = ModelBasedHistoryPlanAgent(
            model, planner, window_length, baseline_agent)

    num_on_policy_iters = (
        (365 * num_years - num_init_random_rollouts) // num_days_on_policy
    )

    for i in range(num_on_policy_iters):
        print('\n--- Iteration {}/{} | dataset={} samples ---'.format(
            i + 1, num_on_policy_iters, len(dataset)))

        agent.set_statistics(dataset)
        agent.fit_dynamic_model(
            dataset=dataset, epoch=training_epochs,
            batch_size=training_batch_size, verbose=True)
        agent.fit_policy(
            dataset=dataset, epoch=training_epochs,
            batch_size=training_batch_size, verbose=True)

        new_data = gather_rollouts(
            env, agent, num_days_on_policy, 96)
        if True:
            stats = new_data.log()
            print(' | '.join(
                ['{}: {:.4f}'.format(k, v) for k, v in stats.items()]))
        dataset.append(new_data)

    print('\nStage 2 training complete.')
    env.close()


# ====================================================================
# CLI
# ====================================================================

def make_parser():
    parser = ArgumentParser(
        description='Grid-Interactive 4-Pipe Fan Coil + DHW Controller')
    sub = parser.add_subparsers(dest='stage', help='Training stage')

    # Stage 1
    s1 = sub.add_parser('stage1', help='Capacity estimation (PID baseline)')
    s1.add_argument('--model_file', type=str, required=True)
    s1.add_argument('--weather_file', type=str, required=True)
    s1.add_argument('--temp_center', type=float, default=22.0)
    s1.add_argument('--dhw_target', type=float, default=55.0)
    s1.add_argument('--dhw_tank_volume', type=float, default=300.0,
                    help='DHW tank volume in liters')

    # Stage 2
    s2 = sub.add_parser('stage2', help='Grid-interactive MBRL training')
    s2.add_argument('--model_file', type=str, required=True)
    s2.add_argument('--weather_file', type=str, required=True)
    s2.add_argument('--temp_center', type=float, default=22.0)
    s2.add_argument('--temp_tolerance', type=float, default=1.5)
    s2.add_argument('--dhw_target', type=float, default=55.0)
    s2.add_argument('--dhw_tank_volume', type=float, default=300.0)
    s2.add_argument('--hvac_max_power', type=float, default=5000.0,
                    help='From Stage 1 report (W)')
    s2.add_argument('--window_length', type=int, default=20)
    s2.add_argument('--num_years', type=int, default=2)
    s2.add_argument('--mpc_horizon', type=int, default=5)
    s2.add_argument('--gamma', type=float, default=0.95)
    s2.add_argument('--num_random_action_selection', type=int, default=4096)
    s2.add_argument('--training_epochs', type=int, default=60)
    s2.add_argument('--training_batch_size', type=int, default=128)
    s2.add_argument('--num_init_random_rollouts', type=int, default=30)
    s2.add_argument('--num_days_on_policy', type=int, default=10)
    s2.add_argument('--dagger', action='store_true')
    s2.add_argument('--w_comfort', type=float, default=2.0)
    s2.add_argument('--w_grid_flex', type=float, default=1.0)
    s2.add_argument('--w_energy_cost', type=float, default=0.5)
    return parser


if __name__ == '__main__':
    parser = make_parser()
    args = parser.parse_args()

    if args.stage is None:
        parser.print_help()
        sys.exit(1)

    pprint.pprint(vars(args))

    if args.stage == 'stage1':
        run_stage1(
            model_file=args.model_file,
            weather_file=args.weather_file,
            temp_center=args.temp_center,
            dhw_target=args.dhw_target,
            dhw_tank_volume=args.dhw_tank_volume,
        )

    elif args.stage == 'stage2':
        run_stage2(
            model_file=args.model_file,
            weather_file=args.weather_file,
            temp_center=args.temp_center,
            temp_tolerance=args.temp_tolerance,
            dhw_target=args.dhw_target,
            dhw_tank_volume=args.dhw_tank_volume,
            hvac_max_power=args.hvac_max_power,
            window_length=args.window_length,
            num_years=args.num_years,
            mpc_horizon=args.mpc_horizon,
            gamma=args.gamma,
            num_random_action_selection=args.num_random_action_selection,
            training_epochs=args.training_epochs,
            training_batch_size=args.training_batch_size,
            num_init_random_rollouts=args.num_init_random_rollouts,
            num_days_on_policy=args.num_days_on_policy,
            dagger=args.dagger,
            w_comfort=args.w_comfort,
            w_grid_flex=args.w_grid_flex,
            w_energy_cost=args.w_energy_cost,
        )
