"""
Validation Script for Building Flexibility Estimation.

Runs 4 levels of checks to verify correctness:

  Level 1: MODEL ACCURACY
    Compare surrogate predictions against EnergyPlus ground truth.
    Metrics: MAE, RMSE, R² for temperatures and power.
    PASS criteria: R² > 0.85 for temperatures, R² > 0.75 for power.

  Level 2: PHYSICAL CONSISTENCY
    Check that predictions obey basic physics:
    - Higher heating setpoint → higher zone temperature
    - Higher HW supply temp → higher power consumption
    - Outdoor temp effect is directionally correct

  Level 3: COMFORT GUARANTEE
    Take the flexibility setpoints and verify in EnergyPlus
    that comfort limits are actually respected.

  Level 4: FLEXIBILITY SANITY
    Check that flexibility values make physical sense:
    - flex_up ≥ 0, flex_down ≥ 0
    - flex_up + flex_down ≤ system max capacity
    - Duration > 0 for non-zero flexibility
    - Conservative ≤ Mean estimate

Usage:
  python validate_results.py \
      --model_file EnergyPlus/Model/renato17_4PipeFanCoil_DHW.idf \
      --weather_file weather/porto.epw \
      --surrogate_path runs/flexibility/surrogate.pt \
      --flexibility_csv runs/flexibility/flexibility_for_gams.csv
"""

import os
import sys
import csv
import json
import numpy as np
from argparse import ArgumentParser

from agent.thermal_surrogate import EnsembleThermalSurrogate


# ====================================================================
# Level 1: Model Accuracy
# ====================================================================

def validate_model_accuracy(surrogate, test_inputs, test_outputs, verbose=True):
    """Compare surrogate predictions against EnergyPlus ground truth.

    Metrics:
      MAE  = (1/N) Σ |y - ŷ|           Mean Absolute Error
      RMSE = √((1/N) Σ (y - ŷ)²)      Root Mean Squared Error
      R²   = 1 - Σ(y - ŷ)² / Σ(y - ȳ)²  Coefficient of Determination
    """
    if verbose:
        print('\n' + '='*60)
        print('  LEVEL 1: Model Accuracy Check')
        print('='*60)

    preds, unc = surrogate.predict(test_inputs)

    labels = [
        'Living Room T', 'Kitchen T', 'Bedroom T', 'Bathroom T',
        'Buffer Tank T', 'DHW Tank T',
        'HVAC Power', 'Total Power',
    ]
    units = ['°C', '°C', '°C', '°C', '°C', '°C', 'W', 'W']

    pred_all = np.column_stack([
        preds['next_zone_temps'],
        preds['next_buffer_T'],
        preds['next_dhw_T'],
        preds['hvac_power'],
        preds['total_power'],
    ])

    results = []
    all_pass = True

    for i, (label, unit) in enumerate(zip(labels, units)):
        y_true = test_outputs[:, i]
        y_pred = pred_all[:, i]

        mae = np.mean(np.abs(y_true - y_pred))
        rmse = np.sqrt(np.mean((y_true - y_pred) ** 2))
        ss_res = np.sum((y_true - y_pred) ** 2)
        ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0

        threshold_r2 = 0.85 if 'T' in label else 0.75
        passed = r2 >= threshold_r2

        if not passed:
            all_pass = False

        results.append({
            'label': label, 'unit': unit,
            'mae': mae, 'rmse': rmse, 'r2': r2,
            'threshold': threshold_r2, 'passed': passed,
        })

        if verbose:
            status = 'PASS' if passed else 'FAIL'
            print('  {:18s}: MAE={:8.2f}{:3s}  RMSE={:8.2f}{:3s}  '
                  'R²={:.4f}  [{}]'.format(
                      label, mae, unit, rmse, unit, r2, status))

    # Uncertainty calibration check
    mean_std = np.mean(unc['total_std'])
    if verbose:
        print('\n  Mean prediction uncertainty: {:.4f}'.format(mean_std))
        print('  Model accuracy: {}'.format(
            'ALL PASSED' if all_pass else 'SOME FAILED'))

    return all_pass, results


# ====================================================================
# Level 2: Physical Consistency
# ====================================================================

def validate_physical_consistency(surrogate, verbose=True):
    """Check that predictions obey basic thermodynamic rules.

    Tests:
      A) Higher heating setpoint → warmer zones (∂T/∂htg_sp > 0)
      B) Higher HW supply temp → more power (∂P/∂hw_T > 0)
      C) Colder outdoor → more heating power (∂P/∂T_out < 0 in winter)
      D) Higher cooling setpoint → less cooling power
    """
    if verbose:
        print('\n' + '='*60)
        print('  LEVEL 2: Physical Consistency Check')
        print('='*60)

    base_zones = [22.0, 21.5, 22.3, 22.5]
    base_conditions = {
        'outdoor_T': 10.0, 'zone_temps': base_zones,
        'buffer_T': 50.0, 'dhw_T': 55.0, 'hour': 12.0,
        'htg_sp': 20.0, 'clg_sp': 26.0, 'hw_T': 50.0, 'dhw_sp': 55.0,
    }

    tests = []

    # Test A: Higher heating setpoint → warmer zones
    base = surrogate.predict_power(**base_conditions)
    modified = dict(base_conditions)
    modified['htg_sp'] = 24.0
    high_htg = surrogate.predict_power(**modified)
    test_a = np.mean(high_htg['next_zone_temps']) >= np.mean(base['next_zone_temps'])
    tests.append(('Higher htg_sp → warmer zones', test_a,
                   np.mean(base['next_zone_temps']),
                   np.mean(high_htg['next_zone_temps'])))

    # Test B: Higher HW supply temp → more power
    modified = dict(base_conditions)
    modified['hw_T'] = 75.0
    high_hw = surrogate.predict_power(**modified)
    test_b = high_hw['total_power'] >= base['total_power']
    tests.append(('Higher hw_T → more power', test_b,
                   base['total_power'], high_hw['total_power']))

    # Test C: Colder outdoor → more heating power
    modified = dict(base_conditions)
    modified['outdoor_T'] = 2.0
    cold = surrogate.predict_power(**modified)
    test_c = cold['total_power'] >= base['total_power']
    tests.append(('Colder outdoor → more power', test_c,
                   base['total_power'], cold['total_power']))

    # Test D: Higher cooling setpoint → less cooling power (summer)
    summer_conditions = dict(base_conditions)
    summer_conditions['outdoor_T'] = 30.0
    summer_conditions['zone_temps'] = [25.0, 24.5, 25.3, 25.5]
    summer_base = surrogate.predict_power(**summer_conditions)
    summer_modified = dict(summer_conditions)
    summer_modified['clg_sp'] = 28.0
    summer_high_clg = surrogate.predict_power(**summer_modified)
    test_d = summer_high_clg['total_power'] <= summer_base['total_power']
    tests.append(('Higher clg_sp → less cooling', test_d,
                   summer_base['total_power'],
                   summer_high_clg['total_power']))

    all_pass = True
    for name, passed, val1, val2 in tests:
        if not passed:
            all_pass = False
        status = 'PASS' if passed else 'FAIL'
        if verbose:
            if isinstance(val1, float):
                print('  {:40s}: {:.1f} → {:.1f}  [{}]'.format(
                    name, val1, val2, status))
            else:
                print('  {:40s}: {:.2f} → {:.2f}  [{}]'.format(
                    name, val1, val2, status))

    if verbose:
        print('\n  Physical consistency: {}'.format(
            'ALL PASSED' if all_pass else 'SOME FAILED'))

    return all_pass, tests


# ====================================================================
# Level 3: Comfort Guarantee
# ====================================================================

def validate_comfort_guarantee(flexibility_csv, comfort_min=20.0,
                               comfort_max=26.0, verbose=True):
    """Verify that flexibility setpoints produce zone temperatures
    within the specified comfort band.

    Checks the conservative (95% confidence) estimates.
    """
    if verbose:
        print('\n' + '='*60)
        print('  LEVEL 3: Comfort Guarantee Check')
        print('='*60)

    with open(flexibility_csv, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    total = len(rows)
    issues = 0

    for row in rows:
        avg_zone = float(row['avg_zone_T_C'])
        # The avg zone should always be within comfort limits
        # (the CEM optimizer enforces this, but let's verify)
        if avg_zone < comfort_min - 1.0 or avg_zone > comfort_max + 1.0:
            issues += 1

    flex_up_vals = [float(r['flex_up_kW']) for r in rows]
    flex_down_vals = [float(r['flex_down_kW']) for r in rows]
    flex_up_95 = [float(r['flex_up_95pct_kW']) for r in rows]
    flex_down_95 = [float(r['flex_down_95pct_kW']) for r in rows]

    # Conservative should always be ≤ mean
    conservative_valid = all(
        float(r['flex_up_95pct_kW']) <= float(r['flex_up_kW']) + 0.001
        for r in rows
    )

    all_pass = (issues == 0) and conservative_valid

    if verbose:
        print('  Total conditions checked: {}'.format(total))
        print('  Zone temp issues: {}'.format(issues))
        print('  Conservative ≤ Mean check: {}'.format(
            'PASS' if conservative_valid else 'FAIL'))
        print('  Comfort guarantee: {}'.format(
            'PASSED' if all_pass else 'FAILED'))

    return all_pass


# ====================================================================
# Level 4: Flexibility Sanity
# ====================================================================

def validate_flexibility_sanity(flexibility_csv, max_system_power_kw=21.0,
                                verbose=True):
    """Check that flexibility values are physically reasonable.

    Rules:
      1) flex_up ≥ 0 and flex_down ≥ 0
      2) flex_up + baseline ≤ max system power
      3) baseline - flex_down ≥ 0
      4) Duration ≥ 0
      5) If flex > 0 then duration > 0
      6) Conservative (95%) ≤ Mean
      7) std ≥ 0
    """
    if verbose:
        print('\n' + '='*60)
        print('  LEVEL 4: Flexibility Sanity Check')
        print('='*60)

    with open(flexibility_csv, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    checks = {
        'flex_non_negative': 0,
        'flex_within_capacity': 0,
        'baseline_minus_down_non_negative': 0,
        'duration_non_negative': 0,
        'nonzero_flex_has_duration': 0,
        'conservative_leq_mean': 0,
        'std_non_negative': 0,
    }
    total = len(rows)

    for r in rows:
        fup = float(r['flex_up_kW'])
        fdn = float(r['flex_down_kW'])
        base = float(r['baseline_kW'])
        fup95 = float(r['flex_up_95pct_kW'])
        fdn95 = float(r['flex_down_95pct_kW'])
        dur_up = float(r['duration_up_h'])
        dur_dn = float(r['duration_down_h'])
        std_up = float(r['flex_up_std_kW'])
        std_dn = float(r['flex_down_std_kW'])

        if fup < -0.001 or fdn < -0.001:
            checks['flex_non_negative'] += 1
        if base + fup > max_system_power_kw * 1.1:
            checks['flex_within_capacity'] += 1
        if base - fdn < -0.1:
            checks['baseline_minus_down_non_negative'] += 1
        if dur_up < 0 or dur_dn < 0:
            checks['duration_non_negative'] += 1
        if fup > 0.1 and dur_up <= 0:
            checks['nonzero_flex_has_duration'] += 1
        if fup95 > fup + 0.01 or fdn95 > fdn + 0.01:
            checks['conservative_leq_mean'] += 1
        if std_up < -0.001 or std_dn < -0.001:
            checks['std_non_negative'] += 1

    all_pass = all(v == 0 for v in checks.values())

    if verbose:
        for check_name, violations in checks.items():
            status = 'PASS' if violations == 0 else 'FAIL ({}/{})'.format(
                violations, total)
            print('  {:45s}: {}'.format(check_name, status))

        fup_vals = [float(r['flex_up_kW']) for r in rows]
        fdn_vals = [float(r['flex_down_kW']) for r in rows]
        base_vals = [float(r['baseline_kW']) for r in rows]

        print('\n  Statistics:')
        print('    Baseline power:     {:.2f} - {:.2f} kW (avg {:.2f})'.format(
            min(base_vals), max(base_vals), np.mean(base_vals)))
        print('    Flex up:            {:.2f} - {:.2f} kW (avg {:.2f})'.format(
            min(fup_vals), max(fup_vals), np.mean(fup_vals)))
        print('    Flex down:          {:.2f} - {:.2f} kW (avg {:.2f})'.format(
            min(fdn_vals), max(fdn_vals), np.mean(fdn_vals)))
        print('\n  Flexibility sanity: {}'.format(
            'ALL PASSED' if all_pass else 'SOME FAILED'))

    return all_pass, checks


# ====================================================================
# Main
# ====================================================================

def run_validation(surrogate_path, flexibility_csv,
                   test_data_inputs=None, test_data_outputs=None,
                   comfort_min=20.0, comfort_max=26.0):
    """Run all 4 levels of validation."""

    print('\n' + '#'*60)
    print('#  VALIDATION REPORT')
    print('#'*60)

    surrogate = EnsembleThermalSurrogate()
    surrogate.load(surrogate_path)
    print('\nLoaded surrogate from {}'.format(surrogate_path))

    results = {}

    # Level 1: Model Accuracy (only if test data provided)
    if test_data_inputs is not None and test_data_outputs is not None:
        p, r = validate_model_accuracy(surrogate, test_data_inputs,
                                       test_data_outputs)
        results['model_accuracy'] = p
    else:
        print('\n  Level 1: SKIPPED (no test data provided)')
        print('  To enable: provide --test_inputs and --test_outputs')
        results['model_accuracy'] = None

    # Level 2: Physical Consistency
    p, _ = validate_physical_consistency(surrogate)
    results['physical_consistency'] = p

    # Level 3: Comfort Guarantee
    p = validate_comfort_guarantee(flexibility_csv, comfort_min, comfort_max)
    results['comfort_guarantee'] = p

    # Level 4: Flexibility Sanity
    p, _ = validate_flexibility_sanity(flexibility_csv)
    results['flexibility_sanity'] = p

    # Summary
    print('\n' + '#'*60)
    print('#  SUMMARY')
    print('#'*60)
    for level, passed in results.items():
        if passed is None:
            status = 'SKIPPED'
        elif passed:
            status = 'PASSED'
        else:
            status = 'FAILED'
        print('  {:30s}: {}'.format(level, status))

    all_passed = all(v is None or v for v in results.values())
    print('\n  Overall: {}'.format(
        'ALL CHECKS PASSED' if all_passed else 'SOME CHECKS FAILED'))

    return results


def make_parser():
    p = ArgumentParser(description='Validate flexibility estimation results')
    p.add_argument('--surrogate_path', type=str, required=True,
                   help='Path to trained surrogate model (.pt)')
    p.add_argument('--flexibility_csv', type=str, required=True,
                   help='Path to flexibility CSV output')
    p.add_argument('--test_inputs', type=str, default=None,
                   help='Path to test inputs .npy (optional)')
    p.add_argument('--test_outputs', type=str, default=None,
                   help='Path to test outputs .npy (optional)')
    p.add_argument('--comfort_min', type=float, default=20.0)
    p.add_argument('--comfort_max', type=float, default=26.0)
    return p


if __name__ == '__main__':
    parser = make_parser()
    args = parser.parse_args()

    test_inputs = None
    test_outputs = None
    if args.test_inputs and args.test_outputs:
        test_inputs = np.load(args.test_inputs)
        test_outputs = np.load(args.test_outputs)

    run_validation(
        surrogate_path=args.surrogate_path,
        flexibility_csv=args.flexibility_csv,
        test_data_inputs=test_inputs,
        test_data_outputs=test_outputs,
        comfort_min=args.comfort_min,
        comfort_max=args.comfort_max,
    )
