"""
Ensemble MLP Dynamics Model for building thermal dynamics.

Instead of a single LSTM+Attention network, this uses an ensemble of N
independent MLP networks. Each network is trained on a different bootstrap
sample of the data, producing diverse predictions.

Key advantage over single-model approach:
  - Uncertainty estimation via prediction disagreement
  - More robust to overfitting
  - Planner can be conservative when uncertainty is high

Architecture per ensemble member:
  Input:  [current_state (13) + action (4)] = 17
  Hidden: 256 -> 256 -> 256 (with LayerNorm + SiLU)
  Output: delta_state mean (13) + delta_state log_var (13)

The model predicts a Gaussian distribution over next-state deltas,
enabling probabilistic planning.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split


class ProbabilisticMLP(nn.Module):
    """Single ensemble member: predicts mean and variance of state delta."""

    def __init__(self, input_dim, output_dim, hidden_dim=256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
        )
        self.mean_head = nn.Linear(hidden_dim, output_dim)
        self.logvar_head = nn.Linear(hidden_dim, output_dim)

        self.max_logvar = nn.Parameter(torch.ones(1, output_dim) * 0.5)
        self.min_logvar = nn.Parameter(-torch.ones(1, output_dim) * 10.0)

    def forward(self, x):
        h = self.net(x)
        mean = self.mean_head(h)
        logvar = self.logvar_head(h)
        logvar = self.max_logvar - F.softplus(self.max_logvar - logvar)
        logvar = self.min_logvar + F.softplus(logvar - self.min_logvar)
        return mean, logvar


class EnsembleDynamicsModel:
    """Ensemble of probabilistic MLP models for building dynamics.

    Learns: S(t+1) = S(t) + f(S(t), A(t))
    where f is predicted as a Gaussian distribution by each ensemble member.
    """

    def __init__(self, state_dim, action_dim, ensemble_size=5,
                 hidden_dim=256, learning_rate=1e-3, device='cpu'):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.ensemble_size = ensemble_size
        self.device = torch.device(device)

        input_dim = state_dim + action_dim
        self.models = nn.ModuleList([
            ProbabilisticMLP(input_dim, state_dim, hidden_dim)
            for _ in range(ensemble_size)
        ]).to(self.device)

        self.optimizer = torch.optim.Adam(
            self.models.parameters(), lr=learning_rate, weight_decay=1e-5)

        self.state_mean = None
        self.state_std = None
        self.action_mean = None
        self.action_std = None
        self.delta_mean = None
        self.delta_std = None

        self._trained = False

    def set_statistics(self, states, actions, next_states):
        """Compute normalization statistics from data."""
        self.state_mean = torch.tensor(
            np.mean(states, axis=0), dtype=torch.float32, device=self.device)
        self.state_std = torch.tensor(
            np.std(states, axis=0) + 1e-8, dtype=torch.float32, device=self.device)
        self.action_mean = torch.tensor(
            np.mean(actions, axis=0), dtype=torch.float32, device=self.device)
        self.action_std = torch.tensor(
            np.std(actions, axis=0) + 1e-8, dtype=torch.float32, device=self.device)

        deltas = next_states - states
        self.delta_mean = torch.tensor(
            np.mean(deltas, axis=0), dtype=torch.float32, device=self.device)
        self.delta_std = torch.tensor(
            np.std(deltas, axis=0) + 1e-8, dtype=torch.float32, device=self.device)

    def _normalize_input(self, states, actions):
        s_norm = (states - self.state_mean) / self.state_std
        a_norm = (actions - self.action_mean) / self.action_std
        return torch.cat([s_norm, a_norm], dim=-1)

    def _normalize_delta(self, delta):
        return (delta - self.delta_mean) / self.delta_std

    def _unnormalize_delta(self, delta_norm):
        return delta_norm * self.delta_std + self.delta_mean

    def fit(self, states, actions, next_states, epochs=50, batch_size=256,
            verbose=False):
        """Train ensemble on collected data.

        Each member trains on a different bootstrap sample.
        """
        self.set_statistics(states, actions, next_states)
        deltas = next_states - states
        N = len(states)

        s_t = torch.tensor(states, dtype=torch.float32, device=self.device)
        a_t = torch.tensor(actions, dtype=torch.float32, device=self.device)
        d_t = torch.tensor(deltas, dtype=torch.float32, device=self.device)

        inputs = self._normalize_input(s_t, a_t)
        targets = self._normalize_delta(d_t)

        for epoch in range(epochs):
            total_loss = 0.0
            for i, model in enumerate(self.models):
                idx = np.random.choice(N, size=N, replace=True)
                inp_boot = inputs[idx]
                tgt_boot = targets[idx]

                for start in range(0, N, batch_size):
                    end = min(start + batch_size, N)
                    inp_b = inp_boot[start:end]
                    tgt_b = tgt_boot[start:end]

                    mean, logvar = model(inp_b)
                    inv_var = torch.exp(-logvar)
                    mse = ((mean - tgt_b) ** 2) * inv_var
                    loss = (mse + logvar).mean()
                    loss += 0.01 * (model.max_logvar.sum() - model.min_logvar.sum())

                    self.optimizer.zero_grad()
                    loss.backward()
                    nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                    self.optimizer.step()
                    total_loss += loss.item()

            if verbose and (epoch + 1) % 10 == 0:
                print('  Dynamics epoch {}/{} - loss: {:.4f}'.format(
                    epoch + 1, epochs, total_loss / self.ensemble_size))

        self._trained = True

    @torch.no_grad()
    def predict(self, states, actions, deterministic=False):
        """Predict next states using ensemble.

        Returns:
            next_states: (batch, state_dim) - ensemble mean prediction
            uncertainty: (batch, state_dim) - prediction disagreement (std across ensemble)
        """
        if isinstance(states, np.ndarray):
            states = torch.tensor(states, dtype=torch.float32, device=self.device)
        if isinstance(actions, np.ndarray):
            actions = torch.tensor(actions, dtype=torch.float32, device=self.device)

        inputs = self._normalize_input(states, actions)

        all_means = []
        for model in self.models:
            model.eval()
            mean, logvar = model(inputs)
            delta = self._unnormalize_delta(mean)
            if not deterministic:
                std = torch.exp(0.5 * logvar) * self.delta_std
                delta = delta + std * torch.randn_like(std)
            all_means.append(states + delta)

        ensemble_preds = torch.stack(all_means, dim=0)
        next_states = ensemble_preds.mean(dim=0)
        uncertainty = ensemble_preds.std(dim=0)

        return next_states, uncertainty

    @torch.no_grad()
    def predict_batch_actions(self, states, actions_batch):
        """Predict for multiple action candidates efficiently.

        Args:
            states: (batch, state_dim) - current states
            actions_batch: (num_candidates, batch, action_dim) - action candidates

        Returns:
            next_states: (num_candidates, batch, state_dim)
            uncertainties: (num_candidates, batch, state_dim)
        """
        num_candidates = actions_batch.shape[0]
        batch_size = states.shape[0]

        states_exp = states.unsqueeze(0).expand(num_candidates, -1, -1)
        states_flat = states_exp.reshape(-1, self.state_dim)
        actions_flat = actions_batch.reshape(-1, self.action_dim)

        next_flat, unc_flat = self.predict(states_flat, actions_flat)

        next_states = next_flat.reshape(num_candidates, batch_size, self.state_dim)
        uncertainties = unc_flat.reshape(num_candidates, batch_size, self.state_dim)
        return next_states, uncertainties

    def save(self, path):
        torch.save({
            'models': self.models.state_dict(),
            'state_mean': self.state_mean,
            'state_std': self.state_std,
            'action_mean': self.action_mean,
            'action_std': self.action_std,
            'delta_mean': self.delta_mean,
            'delta_std': self.delta_std,
        }, path)

    def load(self, path):
        ckpt = torch.load(path, map_location=self.device)
        self.models.load_state_dict(ckpt['models'])
        self.state_mean = ckpt['state_mean']
        self.state_std = ckpt['state_std']
        self.action_mean = ckpt['action_mean']
        self.action_std = ckpt['action_std']
        self.delta_mean = ckpt['delta_mean']
        self.delta_std = ckpt['delta_std']
        self._trained = True
