"""
Utility script to update IDF files from the old pipe-based @ExtCtrl
EMS programs to be compatible with the EnergyPlus Python API (v25.2.0).

Changes:
1. Updates the Version field to 25.2
2. Removes the ExtCtrl initialization program and its calling manager
3. Replaces the ExtCtrlBasedSetpointManager program with a simple
   default-setpoint program (the Python API will override actuators)
"""
import re
import sys
import os


def update_idf(input_path, output_path=None):
    if output_path is None:
        output_path = input_path

    with open(input_path, 'r', encoding='latin-1') as f:
        content = f.read()

    # 1. Update Version
    content = re.sub(
        r'Version,\s*[\d.]+\s*;',
        'Version,25.2;',
        content
    )

    # 2. Remove the ExtCtrl initialization calling manager
    content = re.sub(
        r'\s*EnergyManagementSystem:ProgramCallingManager,\s*\n'
        r'\s*Initialize ExtCtrl-Based Setpoint Manager,.*?\n'
        r'\s*EndOfZoneSizing,.*?\n'
        r'\s*InitializeExtCtrlBasedSetpointManager;.*?\n',
        '\n',
        content,
        flags=re.DOTALL
    )

    # 3. Remove the InitializeExtCtrlBasedSetpointManager program
    content = re.sub(
        r'\s*EnergyManagementSystem:Program,\s*\n'
        r'\s*InitializeExtCtrlBasedSetpointManager,.*?\n'
        r'\s*SET tmp_val1 = @ExtCtrlObs 0;\s*\n',
        '\n',
        content,
        flags=re.DOTALL
    )

    # 4. Replace the ExtCtrlBasedSetpointManager program with default setpoints
    # Match from the program declaration to the ENDIF or end of program
    old_program_pattern = (
        r'EnergyManagementSystem:Program,\s*\n'
        r'\s*ExtCtrlBasedSetpointManager,\s*!-\s*Name\s*\n'
        r'.*?ENDIF;\s*\n'
    )

    has_fan = 'WestZoneSupplyFan_FanAirMassFlowRate' in content

    if has_fan:
        new_program = (
            '  EnergyManagementSystem:Program,\n'
            '    ExtCtrlBasedSetpointManager,                !- Name\n'
            '    SET WestZoneDECOutletNode_setpoint = 23.0,\n'
            '    SET WestZoneIECOutletNode_setpoint = 23.0,\n'
            '    SET WestZoneCCoilAirOutletNode_setpoint = 23.0,\n'
            '    SET WestAirLoopOutletNode_setpoint = 23.0,\n'
            '    SET EastZoneDECOutletNode_setpoint = 23.0,\n'
            '    SET EastZoneIECOutletNode_setpoint = 23.0,\n'
            '    SET EastZoneCCoilAirOutletNode_setpoint = 23.0,\n'
            '    SET EastAirLoopOutletNode_setpoint = 23.0;\n'
        )
    else:
        new_program = (
            '  EnergyManagementSystem:Program,\n'
            '    ExtCtrlBasedSetpointManager,                !- Name\n'
            '    SET WestZoneDECOutletNode_setpoint = 23.0,\n'
            '    SET WestZoneIECOutletNode_setpoint = 23.0,\n'
            '    SET WestZoneCCoilAirOutletNode_setpoint = 23.0,\n'
            '    SET WestAirLoopOutletNode_setpoint = 23.0,\n'
            '    SET EastZoneDECOutletNode_setpoint = 23.0,\n'
            '    SET EastZoneIECOutletNode_setpoint = 23.0,\n'
            '    SET EastZoneCCoilAirOutletNode_setpoint = 23.0,\n'
            '    SET EastAirLoopOutletNode_setpoint = 23.0;\n'
        )

    content = re.sub(old_program_pattern, new_program, content, flags=re.DOTALL)

    with open(output_path, 'w', encoding='latin-1') as f:
        f.write(content)

    print('Updated: {} -> {}'.format(input_path, output_path))


if __name__ == '__main__':
    model_dir = os.path.join(os.path.dirname(__file__), 'EnergyPlus', 'Model')

    for fname in os.listdir(model_dir):
        if fname.endswith('.idf'):
            fpath = os.path.join(model_dir, fname)
            print('Processing: {}'.format(fname))
            update_idf(fpath)

    print('Done. All IDF files updated for EnergyPlus v25.2.0 Python API.')
