# EnergyPlus Integration

## Overview
This project uses **EnergyPlus v25.2.0** with its built-in Python API (`pyenergyplus`)
for reinforcement learning based HVAC control.

**No patching of EnergyPlus is required.** The old pipe-based IPC mechanism has been
replaced with the official EnergyPlus Python API callback system.

## Installation

### Download and Install EnergyPlus v25.2.0
Download from: https://energyplus.net/downloads

#### Ubuntu / Linux
```bash
# Install the .deb or .sh package
sudo dpkg -i EnergyPlus-25.2.0-xxxxxxxx-Linux-Ubuntu22.04-x86_64.deb
# or
sudo bash EnergyPlus-25.2.0-xxxxxxxx-Linux-Ubuntu22.04-x86_64.sh
```

After installation, EnergyPlus is typically at `/usr/local/EnergyPlus-25-2-0/`.

#### macOS
Download and install the .dmg package. EnergyPlus will be in `/Applications/EnergyPlus-25-2-0/`.

### Verify Installation
```bash
# The pyenergyplus module should be available:
python3 -c "import sys; sys.path.insert(0, '/usr/local/EnergyPlus-25-2-0'); from pyenergyplus.api import EnergyPlusAPI; print('OK')"
```

### Environment Variable (optional)
If EnergyPlus is installed in a non-standard location:
```bash
export ENERGYPLUS_DIR=/path/to/EnergyPlus-25-2-0
```

## Model Files
The `Model/` directory contains EnergyPlus IDF model files for a 2-Zone Data Center:

- `2ZoneDataCenterHVAC_wEconomizer-baseline.idf` - Baseline model
- `2ZoneDataCenterHVAC_wEconomizer_Temp.idf` - Temperature setpoint control
- `2ZoneDataCenterHVAC_wEconomizer_Temp_Fan.idf` - Temperature setpoint + fan control

These IDF files have been updated to version 25.2 and the old `@ExtCtrl` EMS programs
have been replaced with default setpoint programs. The Python API overrides actuator
values during simulation through callback functions.

## Architecture
The Python API approach works as follows:
1. EnergyPlus runs in a background thread
2. At each zone timestep, a callback function reads sensor values (temperatures, power)
3. The callback passes observations to the gym environment via a queue
4. The gym environment sends actions back via another queue
5. The callback sets actuator values (setpoints, fan flow rates) and returns

This replaces the old approach of:
- Patching EnergyPlus source code for pipe-based communication
- Running EnergyPlus as a subprocess
- Communicating through named pipes (FIFO)
