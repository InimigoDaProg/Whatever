"""
Cross-Entropy Method (CEM) Planner for Model Predictive Control.

Unlike Random Shooting (which samples uniformly and picks the best),
CEM iteratively refines the action distribution:
  1) Sample N action sequences from current distribution
  2) Evaluate each using the learned dynamics model
  3) Select top-K elites
  4) Fit new distribution (mean, std) to elites
  5) Repeat for M iterations

This converges to good solutions with far fewer samples than
Random Shooting, and naturally handles the constraint that
comfort must be maintained.

Additionally supports uncertainty-penalized planning:
  cost = expected_cost + beta * uncertainty
where beta controls how conservative the planner is.
"""

import numpy as np
import torch


class CEMPlanner:
    """Cross-Entropy Method planner with ensemble uncertainty."""

    def __init__(self, dynamics_model, cost_fn, action_dim, action_low, action_high,
                 horizon=5, num_candidates=200, num_elites=20,
                 cem_iterations=5, uncertainty_penalty=1.0, gamma=0.99,
                 device='cpu'):
        """
        Args:
            dynamics_model: EnsembleDynamicsModel instance
            cost_fn: callable(states, actions, next_states) -> (batch,) costs
            action_dim: dimension of action space
            action_low: (action_dim,) lower bounds
            action_high: (action_dim,) upper bounds
            horizon: planning horizon (number of steps to look ahead)
            num_candidates: number of action sequences sampled per iteration
            num_elites: number of top candidates used to update distribution
            cem_iterations: number of CEM refinement iterations
            uncertainty_penalty: beta coefficient for uncertainty cost
            gamma: discount factor for future costs
        """
        self.dynamics = dynamics_model
        self.cost_fn = cost_fn
        self.action_dim = action_dim
        self.horizon = horizon
        self.num_candidates = num_candidates
        self.num_elites = num_elites
        self.cem_iterations = cem_iterations
        self.uncertainty_penalty = uncertainty_penalty
        self.gamma = gamma
        self.device = torch.device(device)

        self.action_low = torch.tensor(
            action_low, dtype=torch.float32, device=self.device)
        self.action_high = torch.tensor(
            action_high, dtype=torch.float32, device=self.device)

        self._prev_mean = None

    @torch.no_grad()
    def plan(self, current_state, mode_context=None):
        """Plan the best action for the current state using CEM.

        Args:
            current_state: (state_dim,) numpy array
            mode_context: optional dict with high-level mode info
                         {'mode': 'charge'/'discharge'/'normal',
                          'target_buffer_temp': float, ...}

        Returns:
            best_action: (action_dim,) numpy array
            plan_info: dict with planning diagnostics
        """
        state = torch.tensor(
            current_state, dtype=torch.float32, device=self.device
        ).unsqueeze(0)

        action_center = (self.action_low + self.action_high) / 2.0
        action_range = (self.action_high - self.action_low) / 2.0

        if self._prev_mean is not None:
            mean = self._prev_mean.clone()
        else:
            mean = action_center.unsqueeze(0).expand(self.horizon, -1).clone()

        std = action_range.unsqueeze(0).expand(self.horizon, -1).clone() * 0.5

        if mode_context is not None:
            mean = self._apply_mode_bias(mean, mode_context)

        best_cost = float('inf')
        best_action_seq = mean.clone()

        for iteration in range(self.cem_iterations):
            noise = torch.randn(
                self.num_candidates, self.horizon, self.action_dim,
                device=self.device
            )
            action_seqs = mean.unsqueeze(0) + noise * std.unsqueeze(0)
            action_seqs = torch.clamp(action_seqs, self.action_low, self.action_high)

            costs, uncertainties = self._evaluate_sequences(state, action_seqs)

            total_costs = costs + self.uncertainty_penalty * uncertainties

            elite_idx = torch.argsort(total_costs)[:self.num_elites]
            elites = action_seqs[elite_idx]

            new_mean = elites.mean(dim=0)
            new_std = elites.std(dim=0).clamp(min=0.01)

            alpha = 0.25
            mean = alpha * new_mean + (1 - alpha) * mean
            std = alpha * new_std + (1 - alpha) * std

            iter_best = total_costs[elite_idx[0]].item()
            if iter_best < best_cost:
                best_cost = iter_best
                best_action_seq = elites[0].clone()

        self._prev_mean = torch.cat([mean[1:], mean[-1:]], dim=0)

        best_action = best_action_seq[0].cpu().numpy()

        plan_info = {
            'best_cost': best_cost,
            'mean_cost': total_costs.mean().item(),
            'mean_uncertainty': uncertainties.mean().item(),
            'elite_std': std[0].mean().item(),
        }

        return best_action, plan_info

    def _evaluate_sequences(self, initial_state, action_seqs):
        """Roll out action sequences through the dynamics model.

        Args:
            initial_state: (1, state_dim)
            action_seqs: (num_candidates, horizon, action_dim)

        Returns:
            total_costs: (num_candidates,)
            total_uncertainties: (num_candidates,)
        """
        N = action_seqs.shape[0]
        states = initial_state.expand(N, -1).clone()

        total_costs = torch.zeros(N, device=self.device)
        total_uncertainties = torch.zeros(N, device=self.device)
        discount = 1.0

        for t in range(self.horizon):
            actions = action_seqs[:, t, :]

            next_states, uncertainty = self.dynamics.predict(
                states, actions, deterministic=True)

            step_cost = self.cost_fn(states, actions, next_states)
            total_costs += discount * step_cost
            total_uncertainties += discount * uncertainty.mean(dim=-1)

            discount *= self.gamma
            states = next_states

        return total_costs, total_uncertainties

    def _apply_mode_bias(self, mean, mode_context):
        """Bias the initial CEM distribution based on high-level mode."""
        mode = mode_context.get('mode', 'normal')

        if mode == 'charge':
            for t in range(self.horizon):
                mean[t, 2] = min(mean[t, 2] + 10.0, self.action_high[2].item())
                mean[t, 3] = min(mean[t, 3] + 5.0, self.action_high[3].item())
        elif mode == 'discharge':
            for t in range(self.horizon):
                mean[t, 2] = max(mean[t, 2] - 10.0, self.action_low[2].item())
        return mean

    def reset(self):
        """Reset planning state (call at episode boundaries)."""
        self._prev_mean = None
