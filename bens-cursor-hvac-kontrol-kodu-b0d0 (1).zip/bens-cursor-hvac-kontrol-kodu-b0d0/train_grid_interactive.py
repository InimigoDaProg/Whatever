"""
Hierarchical Model-Based RL Training for Grid-Interactive HVAC Control.

Architecture:
  HIGH-LEVEL:  DQN strategy selector (CHARGE / DISCHARGE / NORMAL)
  LOW-LEVEL:   CEM-MPC planner with Ensemble dynamics model
  DYNAMICS:    5x Probabilistic MLP ensemble (uncertainty-aware)

Different from original mbrl-hvac code:
  1) Ensemble MLP instead of single LSTM+Attention
  2) CEM planner instead of Random Shooting
  3) Two-level hierarchical control
  4) Uncertainty-penalized planning
  5) Constraint-based comfort (not weighted sum)

Usage:
  python train_grid_interactive.py \\
      --model_file EnergyPlus/Model/renato17_4PipeFanCoil_DHW.idf \\
      --weather_file /path/to/porto_weather.epw
"""

import os
import sys
import json
import time
import numpy as np
import pprint
from argparse import ArgumentParser
from collections import defaultdict

from gym_energyplus.envs.energyplus_env import EnergyPlusEnv
from gym_energyplus.wrappers import EnergyPlusSplitEpisodeWrapper, Monitor
from agent.ensemble_dynamics import EnsembleDynamicsModel
from agent.hierarchical_agent import HierarchicalGridAgent


# ====================================================================
# Cost function for CEM planner (operates on torch tensors)
# ====================================================================

def make_cost_fn(temp_center, temp_tolerance, dhw_min_temp,
                 comfort_min, comfort_max,
                 w_comfort, w_grid, w_cost, w_uncertainty):
    """Create a cost function closure for the CEM planner.

    This is a CONSTRAINT-BASED cost:
      - Comfort violations are hard penalties (quadratic, steep)
      - Grid flexibility and energy cost are soft objectives
      - DHW safety is a hard constraint
    """
    import torch
    import torch.nn.functional as F

    def cost_fn(states, actions, next_states):
        """
        states/next_states: (batch, 13)
          [0]=outdoor, [1]=living, [2]=kitchen, [3]=bedroom, [4]=bath,
          [5]=buffer_T, [6]=dhw_T, [7]=total_W, [8]=hvac_W,
          [9]=grid_excess, [10]=elec_price, [11]=RH, [12]=avg_zone
        actions: (batch, 4)
          [0]=htg_sp, [1]=clg_sp, [2]=hw_T, [3]=dhw_sp
        """
        avg_zone = next_states[:, 12]
        dhw_T = next_states[:, 6]
        total_W = next_states[:, 7]
        grid_excess = next_states[:, 9]
        elec_price = next_states[:, 10]

        # --- HARD CONSTRAINT: Comfort ---
        soft_viol = (
            F.relu(avg_zone - (temp_center + temp_tolerance))
            + F.relu((temp_center - temp_tolerance) - avg_zone)
        )
        hard_viol = (
            F.relu(avg_zone - comfort_max)
            + F.relu(comfort_min - avg_zone)
        )
        comfort_cost = soft_viol * 2.0 + hard_viol * 10.0

        # --- HARD CONSTRAINT: DHW safety ---
        dhw_cost = F.relu(dhw_min_temp - dhw_T) * 5.0

        # --- SOFT OBJECTIVE: Grid flexibility ---
        grid_benefit = torch.where(
            grid_excess > 0,
            -torch.clamp(total_W, max=grid_excess.abs()) / grid_excess.clamp(min=1.0),
            total_W / 20000.0,
        )

        # --- SOFT OBJECTIVE: Energy cost ---
        energy_cost = total_W * elec_price.clamp(min=0) / 100000.0

        # --- SOFT OBJECTIVE: Comfort Gaussian (reward for being near center) ---
        gauss_reward = torch.exp(-(avg_zone - temp_center) ** 2 * 0.5)

        cost = (comfort_cost * w_comfort
                + dhw_cost
                + grid_benefit * w_grid
                + energy_cost * w_cost
                - gauss_reward * 0.5)

        return cost

    return cost_fn


# ====================================================================
# Data collection
# ====================================================================

def collect_data(env, agent, num_episodes, max_steps_per_episode=96,
                 verbose=False):
    """Collect experience by running agent in environment."""
    all_rewards = []
    all_diagnostics = defaultdict(list)

    for ep in range(num_episodes):
        obs = env.reset()
        agent.reset()
        ep_reward = 0.0
        done = False
        step = 0

        while not done and step < max_steps_per_episode:
            action = agent.predict(obs)
            next_obs, reward, done, info = env.step(action)
            agent.observe(obs, action, reward, next_obs, done)
            ep_reward += reward
            obs = next_obs
            step += 1

            if info.get('true_done', False):
                break

        all_rewards.append(ep_reward)
        diag = agent.get_diagnostics()
        for k, v in diag.items():
            if isinstance(v, (int, float)):
                all_diagnostics[k].append(v)

        if verbose and (ep + 1) % 5 == 0:
            print('  Episode {}/{}: reward={:.2f}, mode={}, data={}'.format(
                ep + 1, num_episodes, ep_reward,
                diag['mode'], diag['data_size']))

    return {
        'mean_reward': np.mean(all_rewards),
        'std_reward': np.std(all_rewards),
        'num_episodes': num_episodes,
        'total_steps': sum(len(r) for r in [all_rewards]),
        **{k: np.mean(v) for k, v in all_diagnostics.items()
           if isinstance(v[0] if v else 0, (int, float))},
    }


# ====================================================================
# Training loop
# ====================================================================

def train(model_file, weather_file, config):
    """Main training loop for hierarchical grid-interactive agent."""

    log_dir = 'runs/grid_hierarchical_{}'.format(
        time.strftime('%Y%m%d_%H%M%S'))
    os.makedirs(log_dir, exist_ok=True)

    with open(os.path.join(log_dir, 'config.json'), 'w') as f:
        json.dump(config, f, indent=2)

    print('\n=== Creating Environment ===')
    env_config = {
        'temp_center': config['temp_center'],
        'temp_tolerance': config['temp_tolerance'],
        'dhw_target': config['dhw_target'],
        'hvac_max_power': config['hvac_max_power'],
        'w_comfort': config['w_comfort'],
        'w_grid_flex': config['w_grid'],
        'w_energy_cost': config['w_cost'],
    }

    env = EnergyPlusEnv(
        model_file=model_file,
        weather_file=weather_file,
        config=env_config,
        verbose=False,
    )
    env = Monitor(env, log_dir=log_dir)
    env = EnergyPlusSplitEpisodeWrapper(env, max_steps=96)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    action_low = env.action_space.low
    action_high = env.action_space.high

    print('State dim: {}, Action dim: {}'.format(state_dim, action_dim))
    print('Action bounds: {} to {}'.format(action_low, action_high))

    print('\n=== Creating Agent ===')
    dynamics = EnsembleDynamicsModel(
        state_dim=state_dim,
        action_dim=action_dim,
        ensemble_size=config['ensemble_size'],
        hidden_dim=config['hidden_dim'],
        learning_rate=config['dynamics_lr'],
        device=config['device'],
    )

    cost_fn = make_cost_fn(
        temp_center=config['temp_center'],
        temp_tolerance=config['temp_tolerance'],
        dhw_min_temp=45.0,
        comfort_min=18.0,
        comfort_max=28.0,
        w_comfort=config['w_comfort'],
        w_grid=config['w_grid'],
        w_cost=config['w_cost'],
        w_uncertainty=config['uncertainty_penalty'],
    )

    agent = HierarchicalGridAgent(
        dynamics_model=dynamics,
        cost_fn=cost_fn,
        action_low=action_low,
        action_high=action_high,
        high_level_interval=config['high_level_interval'],
        mpc_horizon=config['mpc_horizon'],
        cem_candidates=config['cem_candidates'],
        cem_elites=config['cem_elites'],
        cem_iterations=config['cem_iterations'],
        uncertainty_penalty=config['uncertainty_penalty'],
        device=config['device'],
    )

    # --- Phase 1: Random data collection ---
    print('\n=== Phase 1: Random Exploration ({} episodes) ==='.format(
        config['random_episodes']))
    stats = collect_data(
        env, agent, config['random_episodes'],
        verbose=True)
    print('Phase 1 complete: mean_reward={:.2f}, data_size={}'.format(
        stats['mean_reward'], len(agent._data_states)))

    # --- Phase 2: Iterative model training + planning ---
    training_log = []
    best_reward = -float('inf')

    for iteration in range(config['num_iterations']):
        print('\n{"="*60}')
        print('=== Iteration {}/{} ==='.format(
            iteration + 1, config['num_iterations']))
        print('{"="*60}')

        # Train dynamics model
        print('\n--- Training Dynamics Model ---')
        agent.fit_dynamics(epochs=config['dynamics_epochs'], verbose=True)

        # Collect on-policy data with CEM planning
        print('\n--- Collecting On-Policy Data ---')
        stats = collect_data(
            env, agent, config['episodes_per_iter'],
            verbose=True)

        print('\nIteration {} Results:'.format(iteration + 1))
        print('  Mean reward:     {:.2f} +/- {:.2f}'.format(
            stats['mean_reward'], stats['std_reward']))
        print('  Data size:       {}'.format(len(agent._data_states)))
        diag = agent.get_diagnostics()
        print('  HL epsilon:      {:.3f}'.format(diag['epsilon']))
        print('  Current mode:    {}'.format(diag['mode']))

        training_log.append({
            'iteration': iteration + 1,
            **stats,
        })

        if stats['mean_reward'] > best_reward:
            best_reward = stats['mean_reward']
            dynamics.save(os.path.join(log_dir, 'best_dynamics.pt'))
            print('  >>> New best model saved! <<<')

        with open(os.path.join(log_dir, 'training_log.json'), 'w') as f:
            json.dump(training_log, f, indent=2)

    # --- Save final model ---
    dynamics.save(os.path.join(log_dir, 'final_dynamics.pt'))
    print('\n=== Training Complete ===')
    print('Best mean reward: {:.2f}'.format(best_reward))
    print('Results saved to: {}'.format(log_dir))

    env.close()
    return training_log


# ====================================================================
# CLI
# ====================================================================

def make_parser():
    p = ArgumentParser(
        description='Hierarchical Model-Based RL for Grid-Interactive HVAC')

    p.add_argument('--model_file', type=str, required=True,
                   help='Path to EnergyPlus IDF file')
    p.add_argument('--weather_file', type=str, required=True,
                   help='Path to EPW weather file')

    g = p.add_argument_group('Building parameters')
    g.add_argument('--temp_center', type=float, default=22.0)
    g.add_argument('--temp_tolerance', type=float, default=2.0)
    g.add_argument('--dhw_target', type=float, default=55.0)
    g.add_argument('--hvac_max_power', type=float, default=21000.0)

    g = p.add_argument_group('Reward weights')
    g.add_argument('--w_comfort', type=float, default=2.0)
    g.add_argument('--w_grid', type=float, default=1.0)
    g.add_argument('--w_cost', type=float, default=0.5)

    g = p.add_argument_group('Dynamics model')
    g.add_argument('--ensemble_size', type=int, default=5)
    g.add_argument('--hidden_dim', type=int, default=256)
    g.add_argument('--dynamics_lr', type=float, default=1e-3)
    g.add_argument('--dynamics_epochs', type=int, default=50)

    g = p.add_argument_group('CEM Planner')
    g.add_argument('--mpc_horizon', type=int, default=5)
    g.add_argument('--cem_candidates', type=int, default=200)
    g.add_argument('--cem_elites', type=int, default=20)
    g.add_argument('--cem_iterations', type=int, default=5)
    g.add_argument('--uncertainty_penalty', type=float, default=1.0)

    g = p.add_argument_group('Hierarchical')
    g.add_argument('--high_level_interval', type=int, default=16,
                   help='Steps between high-level decisions (16=4hrs at 15min/step)')

    g = p.add_argument_group('Training')
    g.add_argument('--random_episodes', type=int, default=30)
    g.add_argument('--num_iterations', type=int, default=50)
    g.add_argument('--episodes_per_iter', type=int, default=10)
    g.add_argument('--device', type=str, default='cpu',
                   choices=['cpu', 'cuda'])

    return p


if __name__ == '__main__':
    parser = make_parser()
    args = parser.parse_args()
    config = vars(args)

    print('Configuration:')
    pprint.pprint(config)

    model_file = config.pop('model_file')
    weather_file = config.pop('weather_file')

    train(model_file, weather_file, config)
