# Copyright (c) IBM Corp. 2018. All Rights Reserved.
# Project name: Reinforcement Learning Testbed for Power Consumption Optimization
# This project is licensed under the MIT License, see LICENSE

import os
from re import match

from gym_energyplus.envs.energyplus_model_2ZoneDataCenterHVAC_wEconomizer import \
    EnergyPlusModel2ZoneDataCenterHVAC_wEconomizer
from gym_energyplus.envs.energyplus_model_2ZoneDataCenterHVAC_wEconomizer_Temp import \
    EnergyPlusModel2ZoneDataCenterHVAC_wEconomizer_Temp
from gym_energyplus.envs.energyplus_model_2ZoneDataCenterHVAC_wEconomizer_Temp_Fan import \
    EnergyPlusModel2ZoneDataCenterHVAC_wEconomizer_Temp_Fan
from gym_energyplus.envs.energyplus_model_4PipeFanCoil_DHW import \
    EnergyPlusModel4PipeFanCoilDHW


def build_ep_model(model_file, log_dir, config=None, verbose=False):
    model_basename = os.path.splitext(os.path.basename(model_file))[0]

    # 4-Pipe Fan Coil + DHW models
    if match('.*4[Pp]ipe.*[Ff]an[Cc]oil.*', model_basename) or \
       match('.*[Ff]an[Cc]oil.*DHW.*', model_basename) or \
       match('.*FCU.*DHW.*', model_basename):
        model = EnergyPlusModel4PipeFanCoilDHW(
            model_file=model_file, log_dir=log_dir, config=config, verbose=verbose)
    # 2-Zone Data Center models
    elif match('2ZoneDataCenterHVAC_wEconomizer_Temp_Fan.*', model_basename):
        model = EnergyPlusModel2ZoneDataCenterHVAC_wEconomizer_Temp_Fan(
            model_file=model_file, log_dir=log_dir, config=config, verbose=verbose)
    elif match('2ZoneDataCenterHVAC_wEconomizer_Temp.*', model_basename):
        model = EnergyPlusModel2ZoneDataCenterHVAC_wEconomizer_Temp(
            model_file=model_file, log_dir=log_dir, verbose=verbose)
    elif match('2ZoneDataCenterHVAC_wEconomizer.*', model_basename):
        model = EnergyPlusModel2ZoneDataCenterHVAC_wEconomizer(
            model_file=model_file, log_dir=log_dir, verbose=verbose)
    else:
        # Default to 4-pipe fan coil for custom models
        print('INFO: Unrecognized model name "{}". '
              'Defaulting to 4PipeFanCoilDHW model class.'.format(model_basename))
        model = EnergyPlusModel4PipeFanCoilDHW(
            model_file=model_file, log_dir=log_dir, config=config, verbose=verbose)
    return model
